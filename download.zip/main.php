<?php
/**
 * الملف الرئيسي للبوت المنظم
 * يجمع جميع الكلاسات ويوفر واجهة موحدة للبوت
 */

// تضمين جميع الكلاسات
// اختر ملف الإعدادات المناسب
if (file_exists('config_new_bot.php')) {
    require_once 'config_new_bot.php'; // للبوت الجديد
} else {
    require_once 'config.php'; // للبوت الأصلي
}
require_once 'DatabaseManager.php';
require_once 'TelegramBot.php';
require_once 'UserManager.php';
require_once 'ChannelManager.php';
require_once 'ConfigManager.php';
require_once 'CaptchaGenerator.php';
require_once 'PackageManager.php';
require_once 'AutoBackupManager.php';

class OrganizedBot {
    private $db;
    private $bot;
    private $user_manager;
    private $channel_manager;
    private $config_manager;
    private $captcha_generator;
    private $package_manager;
    private $auto_backup_manager;
    private $config;
    private $update;
    
    public function __construct() {
        // تحميل الإعدادات
        $this->config = require 'config.php';
        
        // تهيئة الكلاسات
        $this->db = new DatabaseManager(DATA_DIR);
        $this->bot = new TelegramBot(API_KEY);
        $this->user_manager = new UserManager($this->db, $this->bot);
        $this->channel_manager = new ChannelManager($this->db, $this->bot);
        $this->config_manager = new ConfigManager($this->db);
        $this->captcha_generator = new CaptchaGenerator();
        $this->package_manager = new PackageManager($this->db, $this->user_manager);
        $this->auto_backup_manager = new AutoBackupManager($this->db, $this->bot, 'backups/', 10);
        
        // فحص النسخ الاحتياطي التلقائي
        $this->auto_backup_manager->checkAndBackup();
        
        // معالجة التحديثات
        $this->processUpdate();
    }
    
    /**
     * معالجة تحديثات التليجرام
     */
    private function processUpdate() {
        $input = file_get_contents('php://input');
        $this->update = json_decode($input, true);
        
        if (!$this->update) {
            return;
        }
        
        // استخراج المعلومات الأساسية
        $this->extractUpdateInfo();
        
        // فحص وضع الصيانة
        if ($this->config_manager->isMaintenanceMode()) {
            $this->handleMaintenanceMode();
            return;
        }
        
        // معالجة أنواع التحديثات المختلفة
        if (isset($this->update['message'])) {
            $this->handleMessage();
        } elseif (isset($this->update['callback_query'])) {
            $this->handleCallbackQuery();
        } elseif (isset($this->update['my_chat_member'])) {
            $this->handleChatMemberUpdate();
        }
    }
    
    /**
     * استخراج معلومات التحديث
     */
    private function extractUpdateInfo() {
        if (isset($this->update['message'])) {
            $message = $this->update['message'];
            $this->chat_id = $message['chat']['id'];
            $this->user_id = $message['from']['id'];
            $this->username = $message['from']['username'] ?? '';
            $this->first_name = $message['from']['first_name'] ?? '';
            $this->last_name = $message['from']['last_name'] ?? '';
            $this->text = $message['text'] ?? '';
            $this->message_id = $message['message_id'];
            $this->chat_type = $message['chat']['type'];
        } elseif (isset($this->update['callback_query'])) {
            $callback = $this->update['callback_query'];
            $this->chat_id = $callback['message']['chat']['id'];
            $this->user_id = $callback['from']['id'];
            $this->username = $callback['from']['username'] ?? '';
            $this->first_name = $callback['from']['first_name'] ?? '';
            $this->callback_data = $callback['data'];
            $this->callback_query_id = $callback['id'];
            $this->message_id = $callback['message']['message_id'];
        }
    }
    
    /**
     * معالجة الرسائل
     */
    private function handleMessage() {
        // إضافة المستخدم إذا لم يكن موجوداً
        if (!$this->user_manager->getUser($this->user_id)) {
            $this->user_manager->addUser($this->user_id, [
                'username' => $this->username,
                'first_name' => $this->first_name,
                'last_name' => $this->last_name
            ]);
        }
        
        // فحص إذا كان المستخدم محظور
        if ($this->user_manager->isBlocked($this->user_id)) {
            return;
        }
        
        // فحص الاشتراك الإجباري
        if (!$this->checkSubscription()) {
            return;
        }
        
        // معالجة الأوامر
        if (strpos($this->text, '/') === 0) {
            $this->handleCommand();
        } else {
            $this->handleText();
        }
    }
    
    /**
     * معالجة الأوامر
     */
    private function handleCommand() {
        $command = explode(' ', $this->text)[0];
        
        switch ($command) {
            case '/start':
                $this->handleStart();
                break;
            case '/help':
                $this->handleHelp();
                break;
            case '/profile':
                $this->handleProfile();
                break;
            case '/balance':
                $this->handleBalance();
                break;
            case '/referral':
                $this->handleReferral();
                break;
            case '/admin':
                $this->handleAdmin();
                break;
            default:
                $this->handleUnknownCommand();
        }
    }
    
    /**
     * معالجة النص العادي
     */
    private function handleText() {
        $replies = $this->config_manager->getReplies();
        
        // البحث عن رد تلقائي
        foreach ($replies['default_replies'] as $trigger => $response) {
            if (stripos($this->text, $trigger) !== false) {
                $this->bot->sendMessage($this->chat_id, $response);
                return;
            }
        }
        
        // رسالة افتراضية
        $this->bot->sendMessage($this->chat_id, $this->config_manager->getMessage('help'));
    }
    
    /**
     * معالجة استعلامات Callback
     */
    private function handleCallbackQuery() {
        $this->bot->answerCallbackQuery($this->callback_query_id);
        
        switch ($this->callback_data) {
            case 'profile':
                $this->handleProfile();
                break;
            case 'balance':
                $this->handleBalance();
                break;
            case 'referral':
                $this->handleReferral();
                break;
            case 'admin_panel':
                $this->handleAdminPanel();
                break;
            case 'check_subscription':
                $this->handleCheckSubscription();
                break;
            case 'backup_management':
                $this->handleBackupManagement();
                break;
            case 'create_backup':
                $this->handleCreateBackup();
                break;
            case 'backup_list':
                $this->handleBackupList();
                break;
            default:
                $this->handleUnknownCallback();
        }
    }
    
    /**
     * معالجة أمر /start
     */
    private function handleStart() {
        $user = $this->user_manager->getUser($this->user_id);
        
        // فحص الإحالة
        if (preg_match('/^\/start\s?(\d+)$/', $this->text, $matches)) {
            $referrer_id = $matches[1];
            if ($referrer_id != $this->user_id) {
                $this->user_manager->addReferral($referrer_id, $this->user_id);
            }
        }
        
        $welcome_message = $this->config_manager->getMessage('start');
        $welcome_message = $this->bot->formatText($welcome_message, [
            'coins' => $user['coins'],
            'id' => $this->user_id,
            'name' => $this->first_name
        ]);
        
        $keyboards = $this->config_manager->getKeyboards();
        $this->bot->sendInlineKeyboard($this->chat_id, $welcome_message, $keyboards['main_menu']['inline_keyboard']);
    }
    
    /**
     * معالجة أمر /help
     */
    private function handleHelp() {
        $help_message = $this->config_manager->getMessage('help');
        $this->bot->sendMessage($this->chat_id, $help_message);
    }
    
    /**
     * معالجة أمر /profile
     */
    private function handleProfile() {
        $user_stats = $this->user_manager->getUserStats($this->user_id);
        
        $profile_message = "👤 <b>الملف الشخصي</b>\n\n";
        $profile_message .= "🆔 <b>الآيدي:</b> <code>{$user_stats['user_id']}</code>\n";
        $profile_message .= "👤 <b>الاسم:</b> {$user_stats['first_name']}\n";
        $profile_message .= "📛 <b>المعرف:</b> @{$user_stats['username']}\n";
        $profile_message .= "💰 <b>النقاط:</b> {$user_stats['coins']}\n";
        $profile_message .= "⭐ <b>النجوم:</b> {$user_stats['stars']}\n";
        $profile_message .= "🔗 <b>الإحالات:</b> {$user_stats['referrals_count']}\n";
        $profile_message .= "📅 <b>تاريخ الانضمام:</b> " . date('Y-m-d', $user_stats['join_date']);
        
        $this->bot->sendMessage($this->chat_id, $profile_message);
    }
    
    /**
     * معالجة أمر /balance
     */
    private function handleBalance() {
        $user = $this->user_manager->getUser($this->user_id);
        
        $balance_message = "💰 <b>رصيدك الحالي</b>\n\n";
        $balance_message .= "🪙 <b>النقاط:</b> {$user['coins']}\n";
        $balance_message .= "⭐ <b>النجوم:</b> {$user['stars']}\n";
        $balance_message .= "💸 <b>إجمالي الإنفاق:</b> {$user['total_spent']}\n";
        $balance_message .= "💎 <b>إجمالي الأرباح:</b> {$user['total_earned']}";
        
        $this->bot->sendMessage($this->chat_id, $balance_message);
    }
    
    /**
     * معالجة أمر /referral
     */
    private function handleReferral() {
        $user = $this->user_manager->getUser($this->user_id);
        
        $referral_message = "🔗 <b>نظام الإحالة</b>\n\n";
        $referral_message .= "📊 <b>عدد الإحالات:</b> " . count($user['referrals']) . "\n";
        $referral_message .= "🎁 <b>مكافأة الإحالة:</b> 10 نقاط\n\n";
        $referral_message .= "🔗 <b>رابط الإحالة:</b>\n";
        $referral_message .= "https://t.me/" . $this->bot->getBotInfo()->username . "?start=" . $this->user_id;
        
        $this->bot->sendMessage($this->chat_id, $referral_message);
    }
    
    /**
     * معالجة أمر /admin
     */
    private function handleAdmin() {
        if (!$this->user_manager->isAdmin($this->user_id)) {
            $this->bot->sendMessage($this->chat_id, $this->config_manager->getMessage('access_denied'));
            return;
        }
        
        $this->handleAdminPanel();
    }
    
    /**
     * معالجة لوحة الإدارة
     */
    private function handleAdminPanel() {
        if (!$this->user_manager->isAdmin($this->user_id)) {
            return;
        }
        
        $admin_message = "⚙️ <b>لوحة الإدارة</b>\n\n";
        $admin_message .= "👥 <b>إجمالي المستخدمين:</b> " . count($this->user_manager->getAllUsers()) . "\n";
        $admin_message .= "📊 <b>إجمالي المبيعات:</b> " . $this->package_manager->getSalesStats()['total_sales'] . "\n";
        $admin_message .= "💰 <b>إجمالي الإيرادات:</b> " . $this->package_manager->getSalesStats()['total_revenue'] . "\n";
        
        $keyboards = $this->config_manager->getKeyboards();
        $this->bot->sendInlineKeyboard($this->chat_id, $admin_message, $keyboards['admin_menu']['inline_keyboard']);
    }
    
    /**
     * فحص الاشتراك الإجباري
     */
    private function checkSubscription() {
        $subscription_check = $this->channel_manager->checkCompletedChannels($this->user_id);
        
        if (!$subscription_check['is_completed']) {
            $subscription_data = $this->channel_manager->createSubscriptionMessage($this->user_id, $this->user_manager);
            
            if ($subscription_data) {
                $this->bot->sendInlineKeyboard($this->chat_id, $subscription_data['text'], $subscription_data['keyboard']);
            }
            
            return false;
        }
        
        return true;
    }
    
    /**
     * معالجة فحص الاشتراك
     */
    private function handleCheckSubscription() {
        $subscription_check = $this->channel_manager->checkCompletedChannels($this->user_id);
        
        if ($subscription_check['is_completed']) {
            $this->bot->sendMessage($this->chat_id, "✅ تم التحقق من الاشتراك بنجاح!");
            $this->handleStart(); // إعادة عرض القائمة الرئيسية
        } else {
            $this->bot->sendMessage($this->chat_id, "❌ يجب الاشتراك في جميع القنوات المطلوبة");
        }
    }
    
    /**
     * معالجة تحديثات عضوية المجموعة
     */
    private function handleChatMemberUpdate() {
        $chat_member = $this->update['my_chat_member'];
        $chat = $chat_member['chat'];
        $new_status = $chat_member['new_chat_member']['status'];
        
        if ($new_status === 'member' || $new_status === 'administrator') {
            $this->channel_manager->updateChannelSubscribers($chat['id'], $this->user_id);
        }
    }
    
    /**
     * معالجة وضع الصيانة
     */
    private function handleMaintenanceMode() {
        $maintenance_message = $this->config_manager->getMessage('maintenance');
        $this->bot->sendMessage($this->chat_id, $maintenance_message);
    }
    
    /**
     * معالجة أمر غير معروف
     */
    private function handleUnknownCommand() {
        $this->bot->sendMessage($this->chat_id, $this->config_manager->getMessage('help'));
    }
    
    /**
     * معالجة callback غير معروف
     */
    private function handleUnknownCallback() {
        $this->bot->sendMessage($this->chat_id, $this->config_manager->getMessage('error'));
    }
    
    /**
     * الحصول على إحصائيات البوت
     */
    public function getBotStats() {
        return [
            'users' => count($this->user_manager->getAllUsers()),
            'channels' => $this->channel_manager->getStats(),
            'packages' => $this->package_manager->getSalesStats(),
            'settings' => $this->config_manager->getSettings()
        ];
    }
    
    /**
     * إرسال رسالة للأدمنز
     */
    public function notifyAdmins($message) {
        $admin_ids = array_keys(array_filter($this->user_manager->getAllUsers(), function($user) {
            return $user['is_admin'];
        }));
        
        return $this->bot->notifyAdmins($admin_ids, $message);
    }
    
    /**
     * إرسال رسالة جماعية
     */
    public function broadcast($message, $options = []) {
        $user_ids = array_keys($this->user_manager->getAllUsers());
        return $this->bot->broadcast($user_ids, $message, $options);
    }
    
    /**
     * معالجة إدارة النسخ الاحتياطي
     */
    private function handleBackupManagement() {
        if (!$this->user_manager->isAdmin($this->user_id)) {
            return;
        }
        
        $backup_stats = $this->auto_backup_manager->getBackupStats();
        
        $message = "📦 <b>إدارة النسخ الاحتياطية</b>\n\n";
        $message .= "📊 <b>إحصائيات النسخ:</b>\n";
        $message .= "• إجمالي النسخ: {$backup_stats['total_backups']}\n";
        $message .= "• حجم النسخ: {$backup_stats['total_size_mb']} ميجابايت\n";
        $message .= "• آخر نسخة: {$backup_stats['last_backup']}\n";
        $message .= "• النسخة التالية: {$backup_stats['next_backup']}\n\n";
        $message .= "🔄 <b>النسخ التلقائي:</b> كل 10 دقائق";
        
        $keyboard = [
            [
                ['text' => '📦 إنشاء نسخة يدوية', 'callback_data' => 'create_backup'],
                ['text' => '📋 قائمة النسخ', 'callback_data' => 'backup_list']
            ],
            [
                ['text' => '🔙 لوحة الإدارة', 'callback_data' => 'admin_panel']
            ]
        ];
        
        $this->bot->sendInlineKeyboard($this->chat_id, $message, $keyboard);
    }
    
    /**
     * معالجة إنشاء نسخة احتياطية يدوية
     */
    private function handleCreateBackup() {
        if (!$this->user_manager->isAdmin($this->user_id)) {
            return;
        }
        
        $this->bot->sendMessage($this->chat_id, "📦 جاري إنشاء النسخة الاحتياطية...");
        
        $backup_file = $this->auto_backup_manager->createManualBackup();
        
        if ($backup_file) {
            $message = "✅ <b>تم إنشاء النسخة الاحتياطية بنجاح</b>\n\n";
            $message .= "📁 الملف: " . basename($backup_file) . "\n";
            $message .= "📅 التاريخ: " . date('Y-m-d H:i:s') . "\n";
            $message .= "💾 الحجم: " . round(filesize($backup_file) / 1024 / 1024, 2) . " ميجابايت";
            
            $this->bot->sendMessage($this->chat_id, $message);
        } else {
            $this->bot->sendMessage($this->chat_id, "❌ فشل في إنشاء النسخة الاحتياطية");
        }
    }
    
    /**
     * معالجة قائمة النسخ الاحتياطية
     */
    private function handleBackupList() {
        if (!$this->user_manager->isAdmin($this->user_id)) {
            return;
        }
        
        $backups = $this->auto_backup_manager->getBackupList();
        
        if (empty($backups)) {
            $this->bot->sendMessage($this->chat_id, "📦 لا توجد نسخ احتياطية متاحة");
            return;
        }
        
        $message = "📋 <b>قائمة النسخ الاحتياطية</b>\n\n";
        
        foreach (array_slice($backups, 0, 10) as $backup) {
            $message .= "📦 <b>{$backup['filename']}</b>\n";
            $message .= "📅 {$backup['date']}\n";
            $message .= "💾 " . round($backup['size'] / 1024 / 1024, 2) . " ميجابايت\n\n";
        }
        
        if (count($backups) > 10) {
            $message .= "... و " . (count($backups) - 10) . " نسخة أخرى";
        }
        
        $keyboard = [
            [
                ['text' => '🔙 إدارة النسخ', 'callback_data' => 'backup_management']
            ]
        ];
        
        $this->bot->sendInlineKeyboard($this->chat_id, $message, $keyboard);
    }
}

// تشغيل البوت
try {
    $bot = new OrganizedBot();
} catch (Exception $e) {
    error_log("Bot Error: " . $e->getMessage());
}
?>
