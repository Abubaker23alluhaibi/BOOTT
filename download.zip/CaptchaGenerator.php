<?php
/**
 * كلاس مولد الكابتشا
 * ينشئ صور كابتشا آمنة وجميلة
 */

class CaptchaGenerator {
    private $font_path;
    private $width;
    private $height;
    
    public function __construct($font_path = 'ro.ttf', $width = 320, $height = 120) {
        $this->font_path = $font_path;
        $this->width = $width;
        $this->height = $height;
    }
    
    /**
     * إنشاء كابتشا جديدة
     */
    public function generate($code = null, $length = 4) {
        // توليد كود عشوائي إذا لم يتم توفيره
        if ($code === null) {
            $code = $this->generateRandomCode($length);
        }
        
        // إنشاء الصورة
        $image = imagecreatetruecolor($this->width, $this->height);
        
        // رسم الخلفية المتدرجة
        $this->drawGradientBackground($image);
        
        // إضافة نقاط التشويش
        $this->addNoise($image);
        
        // رسم الخطوط الخلفية
        $this->drawBackgroundLines($image);
        
        // رسم النص
        $this->drawText($image, $code);
        
        // إضافة تشويش إضافي
        $this->addExtraNoise($image);
        
        return [
            'image' => $image,
            'code' => $code
        ];
    }
    
    /**
     * توليد كود عشوائي
     */
    private function generateRandomCode($length) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';
        
        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        return $code;
    }
    
    /**
     * رسم خلفية متدرجة
     */
    private function drawGradientBackground($image) {
        for ($y = 0; $y < $this->height; $y++) {
            $gray = 25 + intval(($y / $this->height) * 40);
            $color = imagecolorallocate($image, $gray, $gray, $gray);
            imageline($image, 0, $y, $this->width, $y, $color);
        }
    }
    
    /**
     * إضافة نقاط التشويش
     */
    private function addNoise($image) {
        $noise_color = imagecolorallocate($image, 70, 70, 70);
        
        for ($i = 0; $i < 500; $i++) {
            imagesetpixel($image, rand(0, $this->width), rand(0, $this->height), $noise_color);
        }
    }
    
    /**
     * رسم الخطوط الخلفية
     */
    private function drawBackgroundLines($image) {
        for ($i = 0; $i < 8; $i++) {
            $line_color = imagecolorallocate($image, rand(40, 70), rand(40, 70), rand(40, 70));
            imageline($image, rand(0, $this->width), rand(0, $this->height),
                      rand(0, $this->width), rand(0, $this->height), $line_color);
        }
    }
    
    /**
     * رسم النص
     */
    private function drawText($image, $code) {
        $font_size = 34;
        $letter_spacing = 10;
        $total_length = strlen($code);
        $total_text_width = ($font_size + $letter_spacing) * $total_length;
        $start_x = ($this->width - $total_text_width) / 2;
        $baseline_y = ($this->height + $font_size) / 2 - 10;
        
        // رسم كل حرف بلون وشكل مختلف
        for ($i = 0; $i < $total_length; $i++) {
            $char = $code[$i];
            $angle = rand(-15, 15);
            $x = $start_x + $i * ($font_size + $letter_spacing);
            $y = $baseline_y + rand(-5, 5);
            
            // لون عشوائي جميل لكل حرف
            $r = rand(100, 255);
            $g = rand(100, 255);
            $b = rand(100, 255);
            $color = imagecolorallocate($image, $r, $g, $b);
            
            // ظل خفيف
            imagettftext($image, $font_size, $angle, $x + 2, $y + 2, 
                        imagecolorallocate($image, 0, 0, 0), $this->font_path, $char);
            
            // الحرف
            imagettftext($image, $font_size, $angle, $x, $y, $color, $this->font_path, $char);
        }
    }
    
    /**
     * إضافة تشويش إضافي
     */
    private function addExtraNoise($image) {
        // إضافة دوائر صغيرة
        for ($i = 0; $i < 20; $i++) {
            $color = imagecolorallocate($image, rand(50, 150), rand(50, 150), rand(50, 150));
            imagefilledellipse($image, rand(0, $this->width), rand(0, $this->height), 
                              rand(2, 8), rand(2, 8), $color);
        }
    }
    
    /**
     * عرض الصورة مباشرة
     */
    public function display($code = null) {
        $result = $this->generate($code);
        
        header('Content-Type: image/png');
        imagepng($result['image']);
        imagedestroy($result['image']);
        
        return $result['code'];
    }
    
    /**
     * حفظ الصورة في ملف
     */
    public function save($filename, $code = null) {
        $result = $this->generate($code);
        
        $success = imagepng($result['image'], $filename);
        imagedestroy($result['image']);
        
        return $success ? $result['code'] : false;
    }
    
    /**
     * الحصول على الصورة كـ base64
     */
    public function getBase64($code = null) {
        $result = $this->generate($code);
        
        ob_start();
        imagepng($result['image']);
        $image_data = ob_get_contents();
        ob_end_clean();
        
        imagedestroy($result['image']);
        
        return [
            'code' => $result['code'],
            'base64' => base64_encode($image_data)
        ];
    }
    
    /**
     * فحص صحة الكود المدخل
     */
    public function verify($input_code, $correct_code) {
        return strtoupper(trim($input_code)) === strtoupper(trim($correct_code));
    }
    
    /**
     * إنشاء كابتشا مع تحديات مختلفة
     */
    public function generateWithChallenge($type = 'text') {
        switch ($type) {
            case 'math':
                return $this->generateMathCaptcha();
            case 'color':
                return $this->generateColorCaptcha();
            default:
                return $this->generate();
        }
    }
    
    /**
     * كابتشا رياضية
     */
    private function generateMathCaptcha() {
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        $operation = rand(0, 1) ? '+' : '-';
        
        if ($operation === '+') {
            $result = $num1 + $num2;
            $question = "$num1 + $num2 = ?";
        } else {
            if ($num1 < $num2) {
                $temp = $num1;
                $num1 = $num2;
                $num2 = $temp;
            }
            $result = $num1 - $num2;
            $question = "$num1 - $num2 = ?";
        }
        
        $image = imagecreatetruecolor($this->width, $this->height);
        $this->drawGradientBackground($image);
        $this->addNoise($image);
        
        // رسم السؤال
        $font_size = 24;
        $text_color = imagecolorallocate($image, 255, 255, 255);
        $x = ($this->width - strlen($question) * 15) / 2;
        $y = $this->height / 2;
        
        imagettftext($image, $font_size, 0, $x, $y, $text_color, $this->font_path, $question);
        
        return [
            'image' => $image,
            'code' => (string)$result,
            'question' => $question
        ];
    }
    
    /**
     * كابتشا ألوان
     */
    private function generateColorCaptcha() {
        $colors = ['أحمر', 'أزرق', 'أخضر', 'أصفر', 'بنفسجي', 'برتقالي'];
        $color_names = ['RED', 'BLUE', 'GREEN', 'YELLOW', 'PURPLE', 'ORANGE'];
        
        $random_index = rand(0, count($colors) - 1);
        $selected_color = $colors[$random_index];
        $selected_color_name = $color_names[$random_index];
        
        $image = imagecreatetruecolor($this->width, $this->height);
        
        // خلفية باللون المحدد
        $color_values = [
            'RED' => [255, 0, 0],
            'BLUE' => [0, 0, 255],
            'GREEN' => [0, 255, 0],
            'YELLOW' => [255, 255, 0],
            'PURPLE' => [128, 0, 128],
            'ORANGE' => [255, 165, 0]
        ];
        
        $bg_color = imagecolorallocate($image, 
            $color_values[$selected_color_name][0],
            $color_values[$selected_color_name][1],
            $color_values[$selected_color_name][2]
        );
        
        imagefill($image, 0, 0, $bg_color);
        
        // رسم النص
        $text_color = imagecolorallocate($image, 255, 255, 255);
        $font_size = 28;
        $x = ($this->width - strlen($selected_color) * 20) / 2;
        $y = $this->height / 2;
        
        imagettftext($image, $font_size, 0, $x, $y, $text_color, $this->font_path, $selected_color);
        
        return [
            'image' => $image,
            'code' => $selected_color_name,
            'question' => "ما هو لون النص؟"
        ];
    }
}
?>
