<?php
/**
 * ملف اختبار البوت المنظم
 * للتأكد من عمل جميع الوظائف مع نفس البوت الحالي
 */

// تضمين الإعدادات
require_once 'config_new_bot.php';

echo "<h2>🤖 اختبار البوت المنظم</h2>";
echo "<p><strong>البوت:</strong> نفس البوت الحالي مع النسخة المنظمة</p>";

// اختبار الاتصال بالتليجرام
echo "<h3>1. اختبار الاتصال بالتليجرام:</h3>";
$bot_info_url = "https://api.telegram.org/bot" . API_KEY . "/getMe";
$response = file_get_contents($bot_info_url);
$bot_info = json_decode($response, true);

if ($bot_info['ok']) {
    echo "✅ البوت متصل بنجاح<br>";
    echo "📛 اسم البوت: " . $bot_info['result']['first_name'] . "<br>";
    echo "🆔 معرف البوت: @" . $bot_info['result']['username'] . "<br>";
} else {
    echo "❌ خطأ في الاتصال: " . $bot_info['description'] . "<br>";
}

// اختبار المجلدات
echo "<h3>2. اختبار المجلدات:</h3>";
if (file_exists(DATA_DIR)) {
    echo "✅ مجلد البيانات موجود<br>";
    if (is_writable(DATA_DIR)) {
        echo "✅ مجلد البيانات قابل للكتابة<br>";
    } else {
        echo "❌ مجلد البيانات غير قابل للكتابة<br>";
    }
} else {
    echo "❌ مجلد البيانات غير موجود<br>";
}

if (file_exists('backups/')) {
    echo "✅ مجلد النسخ الاحتياطي موجود<br>";
} else {
    echo "❌ مجلد النسخ الاحتياطي غير موجود<br>";
}

// اختبار ملفات البيانات
echo "<h3>3. اختبار ملفات البيانات:</h3>";
$data_files = [
    'settings.json',
    'packages.json',
    'channels.json',
    'replies.json',
    'keyboards.json'
];

foreach ($data_files as $file) {
    $file_path = DATA_DIR . $file;
    if (file_exists($file_path)) {
        echo "✅ $file موجود<br>";
    } else {
        echo "❌ $file غير موجود<br>";
    }
}

// اختبار الكلاسات
echo "<h3>4. اختبار الكلاسات:</h3>";
$classes = [
    'DatabaseManager',
    'TelegramBot',
    'UserManager',
    'ChannelManager',
    'ConfigManager',
    'CaptchaGenerator',
    'PackageManager',
    'AutoBackupManager'
];

foreach ($classes as $class) {
    if (class_exists($class)) {
        echo "✅ $class موجود<br>";
    } else {
        echo "❌ $class غير موجود<br>";
    }
}

// معلومات الخادم
echo "<h3>5. معلومات الخادم:</h3>";
echo "🌐 PHP Version: " . phpversion() . "<br>";
echo "📁 Server: " . $_SERVER['SERVER_SOFTWARE'] . "<br>";
echo "🔗 Domain: " . $_SERVER['HTTP_HOST'] . "<br>";
echo "📂 Path: " . __DIR__ . "<br>";

// رابط Webhook
echo "<h3>6. رابط Webhook:</h3>";
$webhook_url = "https://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . "/webhook_new_bot.php";
echo "🔗 رابط Webhook: <a href='$webhook_url' target='_blank'>$webhook_url</a><br>";

echo "<h3>✅ انتهى الاختبار!</h3>";
echo "<p>إذا كانت جميع الاختبارات ناجحة، يمكنك تعيين Webhook الآن.</p>";
?>
