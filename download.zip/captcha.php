<?php
/**
 * ملف الكابتشا المنظم
 * يستخدم كلاس CaptchaGenerator
 */

require_once 'CaptchaGenerator.php';

// الحصول على الكود من المعاملات
$code = $_GET['code'] ?? null;

// إنشاء مولد الكابتشا
$captcha = new CaptchaGenerator();

// عرض الكابتشا
$captcha->display($code);
?>
