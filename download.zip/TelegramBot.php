<?php
/**
 * كلاس إدارة بوت التليجرام
 * يتعامل مع جميع عمليات API التليجرام بطريقة منظمة
 */

class TelegramBot {
    private $api_key;
    private $api_url;
    private $bot_info;
    
    public function __construct($api_key, $api_url = 'https://api.telegram.org/bot') {
        $this->api_key = $api_key;
        $this->api_url = rtrim($api_url, '/') . '/';
        $this->bot_info = null;
    }
    
    /**
     * الحصول على معلومات البوت
     */
    public function getBotInfo() {
        if ($this->bot_info === null) {
            $result = $this->callMethod('getMe');
            if ($result && $result->ok) {
                $this->bot_info = $result->result;
            }
        }
        return $this->bot_info;
    }
    
    /**
     * استدعاء أي method من Telegram API
     */
    public function callMethod($method, $data = []) {
        $url = $this->api_url . $this->api_key . '/' . $method;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen(json_encode($data))
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            return json_decode($response);
        }
        
        return false;
    }
    
    /**
     * إرسال رسالة نصية
     */
    public function sendMessage($chat_id, $text, $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'text' => $text,
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('sendMessage', $data);
    }
    
    /**
     * إرسال رسالة مع أزرار
     */
    public function sendMessageWithKeyboard($chat_id, $text, $keyboard, $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'text' => $text,
            'reply_markup' => json_encode($keyboard),
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('sendMessage', $data);
    }
    
    /**
     * إرسال رسالة مع Inline Keyboard
     */
    public function sendInlineKeyboard($chat_id, $text, $inline_keyboard, $options = []) {
        $keyboard = [
            'inline_keyboard' => $inline_keyboard
        ];
        
        return $this->sendMessageWithKeyboard($chat_id, $text, $keyboard, $options);
    }
    
    /**
     * إرسال رسالة مع Reply Keyboard
     */
    public function sendReplyKeyboard($chat_id, $text, $reply_keyboard, $options = []) {
        $keyboard = [
            'keyboard' => $reply_keyboard,
            'resize_keyboard' => true,
            'one_time_keyboard' => false
        ];
        
        return $this->sendMessageWithKeyboard($chat_id, $text, $keyboard, $options);
    }
    
    /**
     * تعديل رسالة موجودة
     */
    public function editMessage($chat_id, $message_id, $text, $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('editMessageText', $data);
    }
    
    /**
     * تعديل رسالة مع Inline Keyboard
     */
    public function editMessageWithKeyboard($chat_id, $message_id, $text, $inline_keyboard, $options = []) {
        $keyboard = [
            'inline_keyboard' => $inline_keyboard
        ];
        
        $data = array_merge([
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text,
            'reply_markup' => json_encode($keyboard),
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('editMessageText', $data);
    }
    
    /**
     * حذف رسالة
     */
    public function deleteMessage($chat_id, $message_id) {
        return $this->callMethod('deleteMessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id
        ]);
    }
    
    /**
     * الرد على استعلام Callback
     */
    public function answerCallbackQuery($callback_query_id, $text = '', $show_alert = false) {
        return $this->callMethod('answerCallbackQuery', [
            'callback_query_id' => $callback_query_id,
            'text' => $text,
            'show_alert' => $show_alert
        ]);
    }
    
    /**
     * إرسال صورة
     */
    public function sendPhoto($chat_id, $photo, $caption = '', $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'photo' => $photo,
            'caption' => $caption,
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('sendPhoto', $data);
    }
    
    /**
     * إرسال ملف
     */
    public function sendDocument($chat_id, $document, $caption = '', $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'document' => $document,
            'caption' => $caption,
            'parse_mode' => 'HTML'
        ], $options);
        
        return $this->callMethod('sendDocument', $data);
    }
    
    /**
     * إرسال استيكر
     */
    public function sendSticker($chat_id, $sticker, $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'sticker' => $sticker
        ], $options);
        
        return $this->callMethod('sendSticker', $data);
    }
    
    /**
     * إرسال موقع جغرافي
     */
    public function sendLocation($chat_id, $latitude, $longitude, $options = []) {
        $data = array_merge([
            'chat_id' => $chat_id,
            'latitude' => $latitude,
            'longitude' => $longitude
        ], $options);
        
        return $this->callMethod('sendLocation', $data);
    }
    
    /**
     * الحصول على معلومات عضو في مجموعة
     */
    public function getChatMember($chat_id, $user_id) {
        return $this->callMethod('getChatMember', [
            'chat_id' => $chat_id,
            'user_id' => $user_id
        ]);
    }
    
    /**
     * الحصول على معلومات مجموعة
     */
    public function getChat($chat_id) {
        return $this->callMethod('getChat', [
            'chat_id' => $chat_id
        ]);
    }
    
    /**
     * الحصول على إحصائيات البوت
     */
    public function getBotStats() {
        return $this->callMethod('getWebhookInfo');
    }
    
    /**
     * تعيين Webhook
     */
    public function setWebhook($url, $options = []) {
        $data = array_merge([
            'url' => $url
        ], $options);
        
        return $this->callMethod('setWebhook', $data);
    }
    
    /**
     * حذف Webhook
     */
    public function deleteWebhook() {
        return $this->callMethod('deleteWebhook');
    }
    
    /**
     * إرسال رسالة للأدمنز
     */
    public function notifyAdmins($admin_ids, $text, $options = []) {
        $results = [];
        foreach ($admin_ids as $admin_id) {
            $result = $this->sendMessage($admin_id, $text, $options);
            $results[$admin_id] = $result;
        }
        return $results;
    }
    
    /**
     * إرسال رسالة جماعية
     */
    public function broadcast($user_ids, $text, $options = []) {
        $results = [];
        $success = 0;
        $failed = 0;
        
        foreach ($user_ids as $user_id) {
            $result = $this->sendMessage($user_id, $text, $options);
            if ($result && $result->ok) {
                $success++;
                $results[$user_id] = true;
            } else {
                $failed++;
                $results[$user_id] = false;
            }
            
            // تأخير صغير لتجنب Rate Limit
            usleep(100000); // 0.1 ثانية
        }
        
        return [
            'results' => $results,
            'success' => $success,
            'failed' => $failed,
            'total' => count($user_ids)
        ];
    }
    
    /**
     * تنسيق النص للعرض في التليجرام
     */
    public function formatText($text, $variables = []) {
        foreach ($variables as $key => $value) {
            $text = str_replace('#' . $key, $value, $text);
        }
        return $text;
    }
    
    /**
     * إنشاء Inline Keyboard من مصفوفة
     */
    public function createInlineKeyboard($buttons) {
        return [
            'inline_keyboard' => $buttons
        ];
    }
    
    /**
     * إنشاء Reply Keyboard من مصفوفة
     */
    public function createReplyKeyboard($buttons, $resize = true, $one_time = false) {
        return [
            'keyboard' => $buttons,
            'resize_keyboard' => $resize,
            'one_time_keyboard' => $one_time
        ];
    }
}
?>
