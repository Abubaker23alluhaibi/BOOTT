<?php
/**
 * كلاس النسخ الاحتياطي التلقائي
 * يقوم بعمل نسخ احتياطي كل 10 دقائق تلقائياً
 */

class AutoBackupManager {
    private $db;
    private $bot;
    private $backup_dir;
    private $backup_interval;
    
    public function __construct($database_manager, $telegram_bot, $backup_dir = 'backups/', $interval_minutes = 10) {
        $this->db = $database_manager;
        $this->bot = $telegram_bot;
        $this->backup_dir = rtrim($backup_dir, '/') . '/';
        $this->backup_interval = $interval_minutes * 60; // تحويل إلى ثواني
        
        // إنشاء مجلد النسخ الاحتياطي
        if (!file_exists($this->backup_dir)) {
            mkdir($this->backup_dir, 0777, true);
        }
    }
    
    /**
     * فحص وتنفيذ النسخ الاحتياطي التلقائي
     */
    public function checkAndBackup() {
        $last_backup_file = $this->backup_dir . 'last_backup_time.txt';
        $now = time();
        $last_backup_time = file_exists($last_backup_file) ? (int)file_get_contents($last_backup_file) : 0;
        
        // فحص إذا حان وقت النسخ الاحتياطي
        if (($now - $last_backup_time) >= $this->backup_interval) {
            $this->performBackup();
            file_put_contents($last_backup_file, $now);
            return true;
        }
        
        return false;
    }
    
    /**
     * تنفيذ النسخ الاحتياطي
     */
    public function performBackup() {
        try {
            $timestamp = date('Y-m-d_H-i-s');
            $backup_folder = $this->backup_dir . 'auto_backup_' . $timestamp;
            
            // إنشاء مجلد النسخ الاحتياطي
            if (!file_exists($backup_folder)) {
                mkdir($backup_folder, 0777, true);
            }
            
            // نسخ ملفات البيانات
            $this->backupDataFiles($backup_folder);
            
            // إنشاء ملف ZIP
            $zip_file = $this->backup_dir . 'auto_backup_' . $timestamp . '.zip';
            $this->createZipArchive($backup_folder, $zip_file);
            
            // حذف المجلد المؤقت
            $this->deleteDirectory($backup_folder);
            
            // إرسال إشعار للأدمنز
            $this->notifyAdmins($timestamp);
            
            // تنظيف النسخ القديمة
            $this->cleanupOldBackups();
            
            return $zip_file;
            
        } catch (Exception $e) {
            error_log("Backup Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * نسخ ملفات البيانات
     */
    private function backupDataFiles($backup_folder) {
        $data_dir = DATA_DIR;
        $files = glob($data_dir . '*');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                copy($file, $backup_folder . '/' . $filename);
            }
        }
    }
    
    /**
     * إنشاء ملف ZIP
     */
    private function createZipArchive($source_folder, $zip_file) {
        if (!class_exists('ZipArchive')) {
            throw new Exception('ZipArchive class not available');
        }
        
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($source_folder, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            
            foreach ($files as $file) {
                $file_path = $file->getRealPath();
                if (!$file->isDir()) {
                    $relative_path = substr($file_path, strlen($source_folder) + 1);
                    $zip->addFile($file_path, $relative_path);
                }
            }
            
            $zip->close();
            return true;
        }
        
        throw new Exception('Failed to create ZIP archive');
    }
    
    /**
     * حذف مجلد
     */
    private function deleteDirectory($dir) {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->deleteDirectory($path) : unlink($path);
        }
        
        return rmdir($dir);
    }
    
    /**
     * إرسال إشعار للأدمنز
     */
    private function notifyAdmins($timestamp) {
        $admin_ids = $this->getAdminIds();
        
        if (!empty($admin_ids)) {
            $message = "📦 <b>نسخة احتياطية تلقائية</b>\n\n";
            $message .= "✅ تم إنشاء نسخة احتياطية جديدة\n";
            $message .= "📅 التاريخ: " . date('Y-m-d H:i:s') . "\n";
            $message .= "🕐 الوقت: " . $timestamp . "\n\n";
            $message .= "💾 النسخة محفوظة في الخادم";
            
            foreach ($admin_ids as $admin_id) {
                $this->bot->sendMessage($admin_id, $message);
            }
        }
    }
    
    /**
     * الحصول على آيدي الأدمنز
     */
    private function getAdminIds() {
        $users = $this->db->read('users.json', []);
        $admin_ids = [];
        
        foreach ($users as $user_id => $user) {
            if (isset($user['is_admin']) && $user['is_admin']) {
                $admin_ids[] = $user_id;
            }
        }
        
        return $admin_ids;
    }
    
    /**
     * تنظيف النسخ القديمة (الاحتفاظ بآخر 5 نسخ فقط)
     */
    private function cleanupOldBackups() {
        $backup_files = glob($this->backup_dir . 'auto_backup_*.zip');
        
        if (count($backup_files) > 5) {
            // ترتيب الملفات حسب تاريخ الإنشاء
            usort($backup_files, function($a, $b) {
                return filemtime($a) - filemtime($b);
            });
            
            // حذف الملفات القديمة
            $files_to_delete = array_slice($backup_files, 0, count($backup_files) - 5);
            foreach ($files_to_delete as $file) {
                if (file_exists($file)) {
                    unlink($file);
                }
            }
        }
    }
    
    /**
     * إنشاء نسخة احتياطية يدوية
     */
    public function createManualBackup() {
        return $this->performBackup();
    }
    
    /**
     * استرجاع نسخة احتياطية
     */
    public function restoreBackup($zip_file) {
        try {
            if (!file_exists($zip_file)) {
                throw new Exception('Backup file not found');
            }
            
            $temp_dir = $this->backup_dir . 'temp_restore_' . time();
            mkdir($temp_dir, 0777, true);
            
            $zip = new ZipArchive();
            if ($zip->open($zip_file) === TRUE) {
                $zip->extractTo($temp_dir);
                $zip->close();
                
                // نسخ الملفات إلى مجلد البيانات
                $this->restoreDataFiles($temp_dir);
                
                // حذف المجلد المؤقت
                $this->deleteDirectory($temp_dir);
                
                return true;
            }
            
            throw new Exception('Failed to extract backup');
            
        } catch (Exception $e) {
            error_log("Restore Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * استرجاع ملفات البيانات
     */
    private function restoreDataFiles($source_dir) {
        $data_dir = DATA_DIR;
        $files = glob($source_dir . '/*');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                copy($file, $data_dir . $filename);
            }
        }
    }
    
    /**
     * الحصول على قائمة النسخ الاحتياطية
     */
    public function getBackupList() {
        $backup_files = glob($this->backup_dir . 'auto_backup_*.zip');
        $backups = [];
        
        foreach ($backup_files as $file) {
            $backups[] = [
                'filename' => basename($file),
                'path' => $file,
                'size' => filesize($file),
                'created' => filemtime($file),
                'date' => date('Y-m-d H:i:s', filemtime($file))
            ];
        }
        
        // ترتيب حسب التاريخ (الأحدث أولاً)
        usort($backups, function($a, $b) {
            return $b['created'] - $a['created'];
        });
        
        return $backups;
    }
    
    /**
     * الحصول على إحصائيات النسخ الاحتياطي
     */
    public function getBackupStats() {
        $backups = $this->getBackupList();
        $total_size = 0;
        
        foreach ($backups as $backup) {
            $total_size += $backup['size'];
        }
        
        return [
            'total_backups' => count($backups),
            'total_size' => $total_size,
            'total_size_mb' => round($total_size / 1024 / 1024, 2),
            'last_backup' => count($backups) > 0 ? $backups[0]['date'] : 'لم يتم إنشاء نسخ احتياطية',
            'next_backup' => $this->getNextBackupTime()
        ];
    }
    
    /**
     * الحصول على وقت النسخ الاحتياطي التالي
     */
    private function getNextBackupTime() {
        $last_backup_file = $this->backup_dir . 'last_backup_time.txt';
        $last_backup_time = file_exists($last_backup_file) ? (int)file_get_contents($last_backup_file) : 0;
        $next_backup_time = $last_backup_time + $this->backup_interval;
        
        return date('Y-m-d H:i:s', $next_backup_time);
    }
    
    /**
     * تحديث فترة النسخ الاحتياطي
     */
    public function updateBackupInterval($minutes) {
        $this->backup_interval = $minutes * 60;
        return true;
    }
}
?>
