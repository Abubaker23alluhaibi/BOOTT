<?php
/**
 * كلاس إدارة قاعدة البيانات
 * يتعامل مع جميع ملفات JSON بطريقة آمنة ومنظمة
 */

class DatabaseManager {
    private $data_dir;
    private $data_files;
    private $encryption_key;
    
    public function __construct($data_dir = 'data/', $encryption_key = 'default_key_2024') {
        $this->data_dir = rtrim($data_dir, '/') . '/';
        $this->encryption_key = $encryption_key;
        
        // إنشاء مجلد البيانات إذا لم يكن موجوداً
        if (!file_exists($this->data_dir)) {
            mkdir($this->data_dir, 0777, true);
        }
    }
    
    /**
     * قراءة ملف JSON بأمان
     */
    public function read($filename, $default = []) {
        $filepath = $this->data_dir . $filename;
        
        if (!file_exists($filepath)) {
            return $default;
        }
        
        $content = file_get_contents($filepath);
        if ($content === false) {
            return $default;
        }
        
        $data = json_decode($content, true);
        return (is_array($data) || is_object($data)) ? $data : $default;
    }
    
    /**
     * كتابة ملف JSON بأمان
     */
    public function write($filename, $data) {
        $filepath = $this->data_dir . $filename;
        
        // إنشاء المجلد إذا لم يكن موجوداً
        $dir = dirname($filepath);
        if (!file_exists($dir)) {
            mkdir($dir, 0777, true);
        }
        
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        return file_put_contents($filepath, $json) !== false;
    }
    
    /**
     * تشفير البيانات الحساسة
     */
    public function encrypt($data, $key = null) {
        $key = $key ?: $this->encryption_key;
        $cipher = "aes-256-cbc";
        $iv = openssl_random_pseudo_bytes(16);
        
        $encrypted = openssl_encrypt($data, $cipher, $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * فك تشفير البيانات
     */
    public function decrypt($data, $key = null) {
        $key = $key ?: $this->encryption_key;
        $cipher = "aes-256-cbc";
        
        $data = base64_decode($data);
        $iv = substr($data, 0, 16);
        $data = substr($data, 16);
        
        return openssl_decrypt($data, $cipher, $key, 0, $iv);
    }
    
    /**
     * تحديث قيمة محددة في ملف JSON
     */
    public function update($filename, $key, $value) {
        $data = $this->read($filename);
        
        // دعم المفاتيح المتداخلة مثل 'user.coins'
        $keys = explode('.', $key);
        $current = &$data;
        
        foreach ($keys as $k) {
            if (!isset($current[$k])) {
                $current[$k] = [];
            }
            $current = &$current[$k];
        }
        
        $current = $value;
        return $this->write($filename, $data);
    }
    
    /**
     * الحصول على قيمة محددة من ملف JSON
     */
    public function get($filename, $key, $default = null) {
        $data = $this->read($filename);
        
        // دعم المفاتيح المتداخلة
        $keys = explode('.', $key);
        $current = $data;
        
        foreach ($keys as $k) {
            if (!isset($current[$k])) {
                return $default;
            }
            $current = $current[$k];
        }
        
        return $current;
    }
    
    /**
     * حذف ملف
     */
    public function delete($filename) {
        $filepath = $this->data_dir . $filename;
        if (file_exists($filepath)) {
            return unlink($filepath);
        }
        return true;
    }
    
    /**
     * نسخ احتياطي لجميع الملفات
     */
    public function backup($backup_dir = 'backups/') {
        $backup_dir = rtrim($backup_dir, '/') . '/';
        if (!file_exists($backup_dir)) {
            mkdir($backup_dir, 0777, true);
        }
        
        $timestamp = date('Y-m-d_H-i-s');
        $backup_path = $backup_dir . 'backup_' . $timestamp;
        
        if (!file_exists($backup_path)) {
            mkdir($backup_path, 0777, true);
        }
        
        $files = glob($this->data_dir . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                copy($file, $backup_path . '/' . $filename);
            }
        }
        
        return $backup_path;
    }
    
    /**
     * إحصائيات الملفات
     */
    public function getStats() {
        $files = glob($this->data_dir . '*');
        $stats = [
            'total_files' => 0,
            'total_size' => 0,
            'files' => []
        ];
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $stats['total_files']++;
                $size = filesize($file);
                $stats['total_size'] += $size;
                $stats['files'][basename($file)] = [
                    'size' => $size,
                    'modified' => filemtime($file)
                ];
            }
        }
        
        return $stats;
    }
    
    /**
     * تنظيف الملفات المؤقتة
     */
    public function cleanup() {
        $temp_files = glob($this->data_dir . 'temp_*');
        foreach ($temp_files as $file) {
            if (is_file($file) && (time() - filemtime($file)) > 3600) { // أقدم من ساعة
                unlink($file);
            }
        }
    }
}
?>
