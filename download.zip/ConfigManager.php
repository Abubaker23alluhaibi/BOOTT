<?php
/**
 * كلاس إدارة الإعدادات والرسائل
 * يتعامل مع جميع إعدادات البوت والرسائل والردود
 */

class ConfigManager {
    private $db;
    
    public function __construct($database_manager) {
        $this->db = $database_manager;
    }
    
    /**
     * الحصول على إعدادات البوت
     */
    public function getSettings() {
        return $this->db->read('settings.json', [
            'bot_name' => 'بوت HMADA',
            'welcome_message' => 'مرحبا بك في بوت HMADA 🌴',
            'maintenance_mode' => false,
            'registration_enabled' => true,
            'referral_reward' => 10,
            'daily_bonus' => 5,
            'max_daily_bonus' => 50,
            'language' => 'ar',
            'timezone' => 'Asia/Baghdad',
            'currency_symbol' => 'دينار',
            'min_withdrawal' => 100,
            'max_withdrawal' => 10000,
            'admin_notifications' => true,
            'auto_backup' => true,
            'backup_interval' => 24, // ساعات
            'security' => [
                'max_login_attempts' => 5,
                'login_timeout' => 300, // ثواني
                'session_timeout' => 3600, // ساعة
                'enable_captcha' => true,
                'captcha_attempts' => 3
            ],
            'features' => [
                'referral_system' => true,
                'daily_bonus' => true,
                'package_system' => true,
                'subscription_system' => true,
                'broadcast_system' => true,
                'statistics' => true
            ]
        ]);
    }
    
    /**
     * تحديث إعدادات البوت
     */
    public function updateSettings($settings) {
        $current_settings = $this->getSettings();
        $updated_settings = array_merge($current_settings, $settings);
        
        return $this->db->write('settings.json', $updated_settings);
    }
    
    /**
     * الحصول على رسالة محددة
     */
    public function getMessage($message_key, $default = '') {
        $messages = $this->db->read('messages.json', [
            'start' => 'مرحبا بك في بوت HMADA 🌴',
            'help' => 'مرحبا بك في قسم المساعدة',
            'profile' => 'معلوماتك الشخصية',
            'balance' => 'رصيدك الحالي',
            'referral' => 'نظام الإحالة',
            'admin_panel' => 'لوحة الإدارة',
            'error' => 'حدث خطأ، حاول مرة أخرى',
            'success' => 'تم بنجاح',
            'not_found' => 'غير موجود',
            'access_denied' => 'ليس لديك صلاحية',
            'maintenance' => 'البوت في وضع الصيانة',
            'subscription_required' => 'يجب الاشتراك في القنوات المطلوبة',
            'insufficient_balance' => 'رصيدك غير كافي',
            'invalid_input' => 'إدخال غير صحيح',
            'operation_successful' => 'تمت العملية بنجاح',
            'operation_failed' => 'فشلت العملية'
        ]);
        
        return $messages[$message_key] ?? $default;
    }
    
    /**
     * تحديث رسالة محددة
     */
    public function updateMessage($message_key, $message_text) {
        $messages = $this->db->read('messages.json', []);
        $messages[$message_key] = $message_text;
        
        return $this->db->write('messages.json', $messages);
    }
    
    /**
     * الحصول على جميع الرسائل
     */
    public function getAllMessages() {
        return $this->db->read('messages.json', []);
    }
    
    /**
     * تحديث جميع الرسائل
     */
    public function updateAllMessages($messages) {
        return $this->db->write('messages.json', $messages);
    }
    
    /**
     * الحصول على الردود التلقائية
     */
    public function getReplies() {
        return $this->db->read('replies.json', [
            'default_replies' => [
                'مرحبا' => 'مرحبا بك',
                'شكرا' => 'العفو',
                'كيف حالك' => 'بخير والحمد لله',
                'صباح الخير' => 'صباح النور',
                'مساء الخير' => 'مساء النور'
            ],
            'auto_replies' => [
                'enabled' => true,
                'delay' => 1, // ثواني
                'max_replies_per_user' => 10
            ]
        ]);
    }
    
    /**
     * إضافة رد تلقائي جديد
     */
    public function addReply($trigger, $response) {
        $replies = $this->getReplies();
        $replies['default_replies'][$trigger] = $response;
        
        return $this->db->write('replies.json', $replies);
    }
    
    /**
     * حذف رد تلقائي
     */
    public function removeReply($trigger) {
        $replies = $this->getReplies();
        
        if (isset($replies['default_replies'][$trigger])) {
            unset($replies['default_replies'][$trigger]);
            return $this->db->write('replies.json', $replies);
        }
        
        return false;
    }
    
    /**
     * الحصول على الأزرار والقوائم
     */
    public function getKeyboards() {
        return $this->db->read('keyboards.json', [
            'main_menu' => [
                'inline_keyboard' => [
                    [
                        ['text' => '👤 الملف الشخصي', 'callback_data' => 'profile'],
                        ['text' => '💰 الرصيد', 'callback_data' => 'balance']
                    ],
                    [
                        ['text' => '🎁 المكافآت', 'callback_data' => 'rewards'],
                        ['text' => '📊 الإحصائيات', 'callback_data' => 'stats']
                    ],
                    [
                        ['text' => '🔗 الإحالة', 'callback_data' => 'referral'],
                        ['text' => '❓ المساعدة', 'callback_data' => 'help']
                    ]
                ]
            ],
            'admin_menu' => [
                'inline_keyboard' => [
                    [
                        ['text' => '👥 المستخدمين', 'callback_data' => 'admin_users'],
                        ['text' => '📊 الإحصائيات', 'callback_data' => 'admin_stats']
                    ],
                    [
                        ['text' => '📢 الإذاعة', 'callback_data' => 'admin_broadcast'],
                        ['text' => '⚙️ الإعدادات', 'callback_data' => 'admin_settings']
                    ],
                    [
                        ['text' => '🔙 الرئيسية', 'callback_data' => 'main_menu']
                    ]
                ]
            ],
            'reply_keyboard' => [
                'keyboard' => [
                    [
                        ['text' => '🏠 الرئيسية'],
                        ['text' => '👤 الملف الشخصي']
                    ],
                    [
                        ['text' => '💰 الرصيد'],
                        ['text' => '❓ المساعدة']
                    ]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => false
            ]
        ]);
    }
    
    /**
     * تحديث قائمة الأزرار
     */
    public function updateKeyboard($keyboard_name, $keyboard_data) {
        $keyboards = $this->getKeyboards();
        $keyboards[$keyboard_name] = $keyboard_data;
        
        return $this->db->write('keyboards.json', $keyboards);
    }
    
    /**
     * الحصول على إعدادات الأمان
     */
    public function getSecuritySettings() {
        $settings = $this->getSettings();
        return $settings['security'] ?? [
            'max_login_attempts' => 5,
            'login_timeout' => 300,
            'session_timeout' => 3600,
            'enable_captcha' => true,
            'captcha_attempts' => 3
        ];
    }
    
    /**
     * تحديث إعدادات الأمان
     */
    public function updateSecuritySettings($security_settings) {
        $settings = $this->getSettings();
        $settings['security'] = array_merge($settings['security'], $security_settings);
        
        return $this->updateSettings($settings);
    }
    
    /**
     * فحص إذا كان البوت في وضع الصيانة
     */
    public function isMaintenanceMode() {
        $settings = $this->getSettings();
        return $settings['maintenance_mode'] ?? false;
    }
    
    /**
     * تفعيل/إلغاء وضع الصيانة
     */
    public function setMaintenanceMode($enabled) {
        return $this->updateSettings(['maintenance_mode' => $enabled]);
    }
    
    /**
     * فحص إذا كانت الميزة مفعلة
     */
    public function isFeatureEnabled($feature_name) {
        $settings = $this->getSettings();
        return $settings['features'][$feature_name] ?? false;
    }
    
    /**
     * تفعيل/إلغاء ميزة
     */
    public function setFeature($feature_name, $enabled) {
        $settings = $this->getSettings();
        $settings['features'][$feature_name] = $enabled;
        
        return $this->updateSettings($settings);
    }
    
    /**
     * الحصول على إعدادات العملة
     */
    public function getCurrencySettings() {
        $settings = $this->getSettings();
        return [
            'symbol' => $settings['currency_symbol'] ?? 'دينار',
            'min_withdrawal' => $settings['min_withdrawal'] ?? 100,
            'max_withdrawal' => $settings['max_withdrawal'] ?? 10000,
            'referral_reward' => $settings['referral_reward'] ?? 10,
            'daily_bonus' => $settings['daily_bonus'] ?? 5,
            'max_daily_bonus' => $settings['max_daily_bonus'] ?? 50
        ];
    }
    
    /**
     * تحديث إعدادات العملة
     */
    public function updateCurrencySettings($currency_settings) {
        return $this->updateSettings($currency_settings);
    }
    
    /**
     * الحصول على إعدادات النسخ الاحتياطي
     */
    public function getBackupSettings() {
        $settings = $this->getSettings();
        return [
            'auto_backup' => $settings['auto_backup'] ?? true,
            'backup_interval' => $settings['backup_interval'] ?? 24,
            'last_backup' => $settings['last_backup'] ?? 0
        ];
    }
    
    /**
     * تحديث إعدادات النسخ الاحتياطي
     */
    public function updateBackupSettings($backup_settings) {
        return $this->updateSettings($backup_settings);
    }
    
    /**
     * تسجيل آخر نسخة احتياطية
     */
    public function recordBackup() {
        return $this->updateSettings(['last_backup' => time()]);
    }
    
    /**
     * فحص إذا كان الوقت مناسب للنسخ الاحتياطي
     */
    public function shouldBackup() {
        $backup_settings = $this->getBackupSettings();
        
        if (!$backup_settings['auto_backup']) {
            return false;
        }
        
        $last_backup = $backup_settings['last_backup'];
        $interval_hours = $backup_settings['backup_interval'];
        $interval_seconds = $interval_hours * 3600;
        
        return (time() - $last_backup) >= $interval_seconds;
    }
    
    /**
     * تصدير جميع الإعدادات
     */
    public function exportSettings() {
        return [
            'settings' => $this->getSettings(),
            'messages' => $this->getAllMessages(),
            'replies' => $this->getReplies(),
            'keyboards' => $this->getKeyboards(),
            'export_date' => date('Y-m-d H:i:s'),
            'version' => '1.0'
        ];
    }
    
    /**
     * استيراد الإعدادات
     */
    public function importSettings($import_data) {
        $success = true;
        
        if (isset($import_data['settings'])) {
            $success &= $this->updateSettings($import_data['settings']);
        }
        
        if (isset($import_data['messages'])) {
            $success &= $this->updateAllMessages($import_data['messages']);
        }
        
        if (isset($import_data['replies'])) {
            $success &= $this->db->write('replies.json', $import_data['replies']);
        }
        
        if (isset($import_data['keyboards'])) {
            $success &= $this->db->write('keyboards.json', $import_data['keyboards']);
        }
        
        return $success;
    }
    
    /**
     * إعادة تعيين الإعدادات للافتراضية
     */
    public function resetToDefaults() {
        $default_settings = [
            'bot_name' => 'بوت HMADA',
            'welcome_message' => 'مرحبا بك في بوت HMADA 🌴',
            'maintenance_mode' => false,
            'registration_enabled' => true,
            'referral_reward' => 10,
            'daily_bonus' => 5,
            'max_daily_bonus' => 50,
            'language' => 'ar',
            'timezone' => 'Asia/Baghdad',
            'currency_symbol' => 'دينار',
            'min_withdrawal' => 100,
            'max_withdrawal' => 10000,
            'admin_notifications' => true,
            'auto_backup' => true,
            'backup_interval' => 24
        ];
        
        return $this->updateSettings($default_settings);
    }
}
?>
