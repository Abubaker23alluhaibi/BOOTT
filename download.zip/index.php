<?php
/**
 * صفحة فهرس البوت المنظم
 * تعرض معلومات البوت والإحصائيات
 */

// منع الوصول المباشر
if (!isset($_GET['admin']) || $_GET['admin'] !== 'true') {
    die('Access Denied');
}

require_once 'config.php';
require_once 'DatabaseManager.php';
require_once 'TelegramBot.php';
require_once 'UserManager.php';
require_once 'ChannelManager.php';
require_once 'ConfigManager.php';
require_once 'PackageManager.php';

// تهيئة الكلاسات
$db = new DatabaseManager(DATA_DIR);
$bot = new TelegramBot(API_KEY);
$user_manager = new UserManager($db, $bot);
$channel_manager = new ChannelManager($db, $bot);
$config_manager = new ConfigManager($db);
$package_manager = new PackageManager($db, $user_manager);

// الحصول على الإحصائيات
$bot_info = $bot->getBotInfo();
$users_count = count($user_manager->getAllUsers());
$channels_stats = $channel_manager->getStats();
$packages_stats = $package_manager->getSalesStats();
$settings = $config_manager->getSettings();

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 البوت المنظم - لوحة التحكم</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
        }
        
        .stat-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            border-left: 5px solid #667eea;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            color: #667eea;
            font-size: 2em;
            margin-bottom: 10px;
        }
        
        .stat-card p {
            color: #666;
            font-size: 1.1em;
        }
        
        .info-section {
            padding: 30px;
            background: #f8f9fa;
        }
        
        .info-section h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.8em;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .info-card h4 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        
        .info-card ul {
            list-style: none;
        }
        
        .info-card li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
            color: #666;
        }
        
        .info-card li:last-child {
            border-bottom: none;
        }
        
        .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
        }
        
        .status.active {
            background: #d4edda;
            color: #155724;
        }
        
        .status.inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .footer {
            background: #333;
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .footer a {
            color: #667eea;
            text-decoration: none;
        }
        
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 البوت المنظم</h1>
            <p>لوحة تحكم البوت المطور من كود ناميرو</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $users_count; ?></h3>
                <p>👥 إجمالي المستخدمين</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $channels_stats['channels']['total']; ?></h3>
                <p>📺 إجمالي القنوات</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $packages_stats['total_sales']; ?></h3>
                <p>📦 إجمالي المبيعات</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $packages_stats['total_revenue']; ?></h3>
                <p>💰 إجمالي الإيرادات</p>
            </div>
        </div>
        
        <div class="info-section">
            <h2>📊 معلومات البوت</h2>
            <div class="info-grid">
                <div class="info-card">
                    <h4>🤖 معلومات البوت</h4>
                    <ul>
                        <li><strong>اسم البوت:</strong> <?php echo $bot_info->result->first_name ?? 'غير محدد'; ?></li>
                        <li><strong>معرف البوت:</strong> @<?php echo $bot_info->result->username ?? 'غير محدد'; ?></li>
                        <li><strong>آيدي البوت:</strong> <?php echo $bot_info->result->id ?? 'غير محدد'; ?></li>
                        <li><strong>حالة البوت:</strong> 
                            <span class="status <?php echo $settings['maintenance_mode'] ? 'inactive' : 'active'; ?>">
                                <?php echo $settings['maintenance_mode'] ? 'في الصيانة' : 'نشط'; ?>
                            </span>
                        </li>
                    </ul>
                </div>
                
                <div class="info-card">
                    <h4>⚙️ الإعدادات</h4>
                    <ul>
                        <li><strong>اللغة:</strong> <?php echo $settings['language']; ?></li>
                        <li><strong>المنطقة الزمنية:</strong> <?php echo $settings['timezone']; ?></li>
                        <li><strong>رمز العملة:</strong> <?php echo $settings['currency_symbol']; ?></li>
                        <li><strong>مكافأة الإحالة:</strong> <?php echo $settings['referral_reward']; ?> نقطة</li>
                    </ul>
                </div>
                
                <div class="info-card">
                    <h4>🔒 الأمان</h4>
                    <ul>
                        <li><strong>الكابتشا:</strong> 
                            <span class="status <?php echo $settings['security']['enable_captcha'] ? 'active' : 'inactive'; ?>">
                                <?php echo $settings['security']['enable_captcha'] ? 'مفعلة' : 'معطلة'; ?>
                            </span>
                        </li>
                        <li><strong>النسخ الاحتياطي:</strong> 
                            <span class="status <?php echo $settings['auto_backup'] ? 'active' : 'inactive'; ?>">
                                <?php echo $settings['auto_backup'] ? 'مفعل' : 'معطل'; ?>
                            </span>
                        </li>
                        <li><strong>فترة النسخ:</strong> كل <?php echo $settings['backup_interval']; ?> ساعة</li>
                    </ul>
                </div>
                
                <div class="info-card">
                    <h4>🎯 الميزات</h4>
                    <ul>
                        <li><strong>نظام الإحالة:</strong> 
                            <span class="status <?php echo $settings['features']['referral_system'] ? 'active' : 'inactive'; ?>">
                                <?php echo $settings['features']['referral_system'] ? 'مفعل' : 'معطل'; ?>
                            </span>
                        </li>
                        <li><strong>نظام الباقات:</strong> 
                            <span class="status <?php echo $settings['features']['package_system'] ? 'active' : 'inactive'; ?>">
                                <?php echo $settings['features']['package_system'] ? 'مفعل' : 'معطل'; ?>
                            </span>
                        </li>
                        <li><strong>الاشتراك الإجباري:</strong> 
                            <span class="status <?php echo $settings['features']['subscription_system'] ? 'active' : 'inactive'; ?>">
                                <?php echo $settings['features']['subscription_system'] ? 'مفعل' : 'معطل'; ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>🤖 <strong>البوت المنظم</strong> - مطور من كود ناميرو الأصلي</p>
            <p>المطور الأصلي: <a href="https://t.me/s_p_p1" target="_blank">ناميرو</a> | القناة: <a href="https://t.me/bots_5" target="_blank">@bots_5</a></p>
            <p>الإصدار: 2.0 (منظم) | آخر تحديث: <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>
