<?php
/**
 * ملف مثال للإعداد
 * انسخ هذا الملف إلى config.php وعدل القيم حسب احتياجاتك
 */

// إعدادات البوت الأساسية
define('API_KEY', 'YOUR_BOT_TOKEN_HERE'); // ضع توكن البوت هنا
define('SUDO_ID', 'YOUR_USER_ID_HERE'); // ضع آيدي المطور هنا
define('CAPTCHA_PATH', 'captcha.php'); // مسار ملف الكابتشا

// إعدادات قاعدة البيانات
define('DATA_DIR', 'data/');
define('BOT_USERNAME', ''); // سيتم تعيينه تلقائياً

// إعدادات الوقت والمنطقة الزمنية
date_default_timezone_set('Asia/Baghdad');

// إعدادات PHP
error_reporting(0);
ini_set('display_errors', 1);
ini_set('memory_limit', '256M');
set_time_limit(0);
ignore_user_abort(true);
ini_set('max_execution_time', 300);

// رسائل البوت الافتراضية
define('DEFAULT_START_MESSAGE', "
مرحبا بك في بوت HMADA 🌴

💰] رصيدك : #coins دينار
✅] ايديك : #id
");

// إعدادات الملفات
$config = [
    'admin' => SUDO_ID,
    'token' => API_KEY,
    'error_report' => 0,
    'api_url' => 'api.telegram.org',
    'msg_error' => 'Req Failed .',
    'type_up' => 'php://input',
    'start_msg' => DEFAULT_START_MESSAGE,
];

// إنشاء المجلدات المطلوبة
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0777, true);
}

// ملفات البيانات
$data_files = [
    'tasks' => DATA_DIR . 'tasks.json',
    'enters' => DATA_DIR . 'enters.json',
    'modes' => DATA_DIR . 'modes.json',
    'fords' => DATA_DIR . 'fords.json',
    'rdods' => DATA_DIR . 'rdods.json',
    'start' => DATA_DIR . 'start.json',
    'commands' => DATA_DIR . 'commands.json',
    'admins' => DATA_DIR . 'admins.json',
    'shtrak' => DATA_DIR . 'shtrak.json',
    'helper' => DATA_DIR . 'helper.json',
    'members' => DATA_DIR . 'members.json',
    'channels' => DATA_DIR . 'channels.json',
    'groups' => DATA_DIR . 'groups.json',
    'blockers' => DATA_DIR . 'blockers.json',
    'settings' => DATA_DIR . 'settings.json',
    'sales' => DATA_DIR . 'sales.json',
    'rshq' => DATA_DIR . 'rshq.json',
    'packages' => DATA_DIR . 'packages.json',
    'user_packages' => DATA_DIR . 'user_packages.json',
    'counter_sales' => DATA_DIR . 'counter_sales.json',
    'counter_stats' => DATA_DIR . 'counter_stats.json',
    'counter_allowed' => DATA_DIR . 'counter_allowed.json',
    'counter_last' => DATA_DIR . 'counter_last.json',
    'counter_settings' => DATA_DIR . 'counter_settings.json',
];

// إضافة مسارات الملفات للكونفيج
$config['data_files'] = $data_files;

return $config;

/*
تعليمات الإعداد:

1. انسخ هذا الملف إلى config.php
2. ضع توكن البوت في API_KEY
3. ضع آيدي المطور في SUDO_ID
4. تأكد من صلاحيات الكتابة على مجلد data/
5. ارفع جميع الملفات إلى الخادم
6. عين main.php كـ webhook للبوت

مثال على تعيين webhook:
https://api.telegram.org/botYOUR_BOT_TOKEN/setWebhook?url=https://yourdomain.com/organized_bot/main.php

أو استخدم هذا الرابط في المتصفح:
https://api.telegram.org/botYOUR_BOT_TOKEN/setWebhook?url=https://yourdomain.com/organized_bot/main.php
*/
?>
