<?php
/**
 * كلاس إدارة الباقات والعروض
 * يتعامل مع نظام الباقات والمكافآت والمبيعات
 */

class PackageManager {
    private $db;
    private $user_manager;
    
    public function __construct($database_manager, $user_manager) {
        $this->db = $database_manager;
        $this->user_manager = $user_manager;
    }
    
    /**
     * الحصول على جميع الباقات
     */
    public function getAllPackages() {
        return $this->db->read('packages.json', [
            [
                'id' => 1,
                'name' => 'باقة المبتدئ',
                'points' => 100,
                'stars' => 2,
                'price' => 0,
                'description' => 'باقة مجانية للمبتدئين',
                'is_active' => true,
                'created_date' => time()
            ],
            [
                'id' => 2,
                'name' => 'باقة المتوسط',
                'points' => 500,
                'stars' => 8,
                'price' => 0,
                'description' => 'باقة متوسطة للمستخدمين النشطين',
                'is_active' => true,
                'created_date' => time()
            ],
            [
                'id' => 3,
                'name' => 'باقة المتقدم',
                'points' => 1000,
                'stars' => 15,
                'price' => 0,
                'description' => 'باقة متقدمة للمستخدمين المتميزين',
                'is_active' => true,
                'created_date' => time()
            ],
            [
                'id' => 4,
                'name' => 'باقة VIP',
                'points' => 5000,
                'stars' => 70,
                'price' => 0,
                'description' => 'باقة VIP للمستخدمين المميزين',
                'is_active' => true,
                'created_date' => time()
            ]
        ]);
    }
    
    /**
     * إضافة باقة جديدة
     */
    public function addPackage($package_data) {
        $packages = $this->getAllPackages();
        
        $new_package = array_merge([
            'id' => $this->getNextPackageId(),
            'name' => '',
            'points' => 0,
            'stars' => 0,
            'price' => 0,
            'description' => '',
            'is_active' => true,
            'created_date' => time()
        ], $package_data);
        
        $packages[] = $new_package;
        $this->db->write('packages.json', $packages);
        
        return $new_package['id'];
    }
    
    /**
     * تحديث باقة موجودة
     */
    public function updatePackage($package_id, $package_data) {
        $packages = $this->getAllPackages();
        
        foreach ($packages as $index => $package) {
            if ($package['id'] == $package_id) {
                $packages[$index] = array_merge($package, $package_data);
                $this->db->write('packages.json', $packages);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * حذف باقة
     */
    public function deletePackage($package_id) {
        $packages = $this->getAllPackages();
        
        foreach ($packages as $index => $package) {
            if ($package['id'] == $package_id) {
                unset($packages[$index]);
                $packages = array_values($packages);
                $this->db->write('packages.json', $packages);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * الحصول على باقة محددة
     */
    public function getPackage($package_id) {
        $packages = $this->getAllPackages();
        
        foreach ($packages as $package) {
            if ($package['id'] == $package_id) {
                return $package;
            }
        }
        
        return null;
    }
    
    /**
     * شراء باقة من قبل مستخدم
     */
    public function purchasePackage($user_id, $package_id) {
        $package = $this->getPackage($package_id);
        if (!$package || !$package['is_active']) {
            return false;
        }
        
        $user = $this->user_manager->getUser($user_id);
        if (!$user) {
            return false;
        }
        
        // فحص إذا كان المستخدم يملك النقاط الكافية
        if ($package['price'] > 0 && $user['coins'] < $package['price']) {
            return false;
        }
        
        // خصم السعر إذا كان مدفوع
        if ($package['price'] > 0) {
            $this->user_manager->deductCoins($user_id, $package['price'], "شراء باقة: " . $package['name']);
        }
        
        // إضافة الباقة للمستخدم
        $this->addUserPackage($user_id, $package_id, $package);
        
        // تسجيل عملية البيع
        $this->recordSale($user_id, $package_id, $package);
        
        return true;
    }
    
    /**
     * إضافة باقة لمستخدم
     */
    public function addUserPackage($user_id, $package_id, $package = null) {
        if (!$package) {
            $package = $this->getPackage($package_id);
        }
        
        if (!$package) return false;
        
        $user_packages = $this->db->read('user_packages.json', []);
        
        if (!isset($user_packages[$user_id])) {
            $user_packages[$user_id] = [];
        }
        
        $user_packages[$user_id][] = [
            'package_id' => $package_id,
            'package_name' => $package['name'],
            'points' => $package['points'],
            'stars' => $package['stars'],
            'purchase_date' => time(),
            'expiry_date' => time() + (30 * 24 * 60 * 60), // 30 يوم
            'is_active' => true
        ];
        
        $this->db->write('user_packages.json', $user_packages);
        
        // إضافة النقاط والنجوم للمستخدم
        $this->user_manager->addCoins($user_id, $package['points'], "باقة: " . $package['name']);
        $this->user_manager->addStars($user_id, $package['stars'], "باقة: " . $package['name']);
        
        return true;
    }
    
    /**
     * الحصول على باقات مستخدم
     */
    public function getUserPackages($user_id) {
        $user_packages = $this->db->read('user_packages.json', []);
        return $user_packages[$user_id] ?? [];
    }
    
    /**
     * تنظيف الباقات المنتهية الصلاحية
     */
    public function cleanExpiredPackages($user_id = null) {
        $user_packages = $this->db->read('user_packages.json', []);
        $cleaned_count = 0;
        
        foreach ($user_packages as $uid => $packages) {
            if ($user_id && $uid != $user_id) continue;
            
            foreach ($packages as $index => $package) {
                if ($package['expiry_date'] < time() && $package['is_active']) {
                    $user_packages[$uid][$index]['is_active'] = false;
                    $cleaned_count++;
                }
            }
        }
        
        if ($cleaned_count > 0) {
            $this->db->write('user_packages.json', $user_packages);
        }
        
        return $cleaned_count;
    }
    
    /**
     * تسجيل عملية بيع
     */
    public function recordSale($user_id, $package_id, $package) {
        $sales = $this->db->read('sales.json', []);
        
        $sale = [
            'user_id' => $user_id,
            'package_id' => $package_id,
            'package_name' => $package['name'],
            'points' => $package['points'],
            'stars' => $package['stars'],
            'price' => $package['price'],
            'sale_date' => time(),
            'date' => date('Y-m-d H:i:s')
        ];
        
        $sales[] = $sale;
        $this->db->write('sales.json', $sales);
        
        // تحديث الإحصائيات
        $this->updateSalesStats($package_id, $package['price']);
    }
    
    /**
     * تحديث إحصائيات المبيعات
     */
    public function updateSalesStats($package_id, $price) {
        $stats = $this->db->read('sales_stats.json', [
            'total_sales' => 0,
            'total_revenue' => 0,
            'packages' => []
        ]);
        
        $stats['total_sales']++;
        $stats['total_revenue'] += $price;
        
        if (!isset($stats['packages'][$package_id])) {
            $stats['packages'][$package_id] = [
                'sales_count' => 0,
                'revenue' => 0
            ];
        }
        
        $stats['packages'][$package_id]['sales_count']++;
        $stats['packages'][$package_id]['revenue'] += $price;
        
        $this->db->write('sales_stats.json', $stats);
    }
    
    /**
     * الحصول على إحصائيات المبيعات
     */
    public function getSalesStats() {
        return $this->db->read('sales_stats.json', [
            'total_sales' => 0,
            'total_revenue' => 0,
            'packages' => []
        ]);
    }
    
    /**
     * الحصول على مبيعات فترة محددة
     */
    public function getSalesByPeriod($start_date, $end_date) {
        $sales = $this->db->read('sales.json', []);
        $filtered_sales = [];
        
        foreach ($sales as $sale) {
            if ($sale['sale_date'] >= $start_date && $sale['sale_date'] <= $end_date) {
                $filtered_sales[] = $sale;
            }
        }
        
        return $filtered_sales;
    }
    
    /**
     * الحصول على أفضل الباقات مبيعاً
     */
    public function getTopSellingPackages($limit = 5) {
        $stats = $this->getSalesStats();
        $packages = $stats['packages'];
        
        // ترتيب حسب عدد المبيعات
        uasort($packages, function($a, $b) {
            return $b['sales_count'] - $a['sales_count'];
        });
        
        return array_slice($packages, 0, $limit, true);
    }
    
    /**
     * إنشاء تقرير مبيعات
     */
    public function generateSalesReport($period_days = 30) {
        $end_date = time();
        $start_date = $end_date - ($period_days * 24 * 60 * 60);
        
        $sales = $this->getSalesByPeriod($start_date, $end_date);
        $stats = $this->getSalesStats();
        
        $report = [
            'period' => [
                'start_date' => date('Y-m-d', $start_date),
                'end_date' => date('Y-m-d', $end_date),
                'days' => $period_days
            ],
            'sales' => [
                'total_sales' => count($sales),
                'total_revenue' => array_sum(array_column($sales, 'price')),
                'average_sale' => count($sales) > 0 ? array_sum(array_column($sales, 'price')) / count($sales) : 0
            ],
            'packages' => [],
            'daily_sales' => []
        ];
        
        // إحصائيات الباقات
        foreach ($sales as $sale) {
            $package_id = $sale['package_id'];
            if (!isset($report['packages'][$package_id])) {
                $report['packages'][$package_id] = [
                    'name' => $sale['package_name'],
                    'sales_count' => 0,
                    'revenue' => 0
                ];
            }
            
            $report['packages'][$package_id]['sales_count']++;
            $report['packages'][$package_id]['revenue'] += $sale['price'];
        }
        
        // إحصائيات يومية
        for ($i = 0; $i < $period_days; $i++) {
            $date = $start_date + ($i * 24 * 60 * 60);
            $day_sales = array_filter($sales, function($sale) use ($date) {
                return date('Y-m-d', $sale['sale_date']) === date('Y-m-d', $date);
            });
            
            $report['daily_sales'][date('Y-m-d', $date)] = [
                'sales_count' => count($day_sales),
                'revenue' => array_sum(array_column($day_sales, 'price'))
            ];
        }
        
        return $report;
    }
    
    /**
     * الحصول على معرف الباقة التالي
     */
    private function getNextPackageId() {
        $packages = $this->getAllPackages();
        $max_id = 0;
        
        foreach ($packages as $package) {
            $max_id = max($max_id, $package['id']);
        }
        
        return $max_id + 1;
    }
    
    /**
     * إنشاء عرض خاص
     */
    public function createSpecialOffer($package_id, $discount_percent, $expiry_hours = 24) {
        $package = $this->getPackage($package_id);
        if (!$package) return false;
        
        $offer = [
            'package_id' => $package_id,
            'original_price' => $package['price'],
            'discount_percent' => $discount_percent,
            'discounted_price' => $package['price'] * (1 - $discount_percent / 100),
            'created_date' => time(),
            'expiry_date' => time() + ($expiry_hours * 60 * 60),
            'is_active' => true
        ];
        
        $offers = $this->db->read('special_offers.json', []);
        $offers[] = $offer;
        
        $this->db->write('special_offers.json', $offers);
        
        return $offer;
    }
    
    /**
     * الحصول على العروض الخاصة النشطة
     */
    public function getActiveOffers() {
        $offers = $this->db->read('special_offers.json', []);
        $active_offers = [];
        
        foreach ($offers as $offer) {
            if ($offer['is_active'] && $offer['expiry_date'] > time()) {
                $active_offers[] = $offer;
            }
        }
        
        return $active_offers;
    }
}
?>
