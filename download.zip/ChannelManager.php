<?php
/**
 * كلاس إدارة القنوات والمجموعات
 * يتعامل مع نظام الاشتراك الإجباري وإدارة القنوات
 */

class ChannelManager {
    private $db;
    private $bot;
    
    public function __construct($database_manager, $telegram_bot) {
        $this->db = $database_manager;
        $this->bot = $telegram_bot;
    }
    
    /**
     * إضافة قناة جديدة
     */
    public function addChannel($channel_id, $channel_data = []) {
        $channels = $this->db->read('channels.json', ['channels' => []]);
        
        $channel_info = array_merge([
            'channel_id' => $channel_id,
            'title' => $channel_data['title'] ?? '',
            'username' => $channel_data['username'] ?? '',
            'invite_link' => $channel_data['invite_link'] ?? '',
            'required_count' => $channel_data['required_count'] ?? 0,
            'current_count' => 0,
            'subscribers' => [],
            'completed' => false,
            'is_active' => true,
            'added_date' => time(),
            'reward_coins' => $channel_data['reward_coins'] ?? 0,
            'reward_stars' => $channel_data['reward_stars'] ?? 0
        ], $channel_data);
        
        // فحص إذا كانت القناة موجودة مسبقاً
        foreach ($channels['channels'] as $existing_channel) {
            if ($existing_channel['channel_id'] == $channel_id) {
                return false; // القناة موجودة مسبقاً
            }
        }
        
        $channels['channels'][] = $channel_info;
        $this->db->write('channels.json', $channels);
        
        return true;
    }
    
    /**
     * حذف قناة
     */
    public function removeChannel($channel_id) {
        $channels = $this->db->read('channels.json', ['channels' => []]);
        
        foreach ($channels['channels'] as $index => $channel) {
            if ($channel['channel_id'] == $channel_id) {
                unset($channels['channels'][$index]);
                $channels['channels'] = array_values($channels['channels']); // إعادة ترقيم المصفوفة
                $this->db->write('channels.json', $channels);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * الحصول على جميع القنوات
     */
    public function getAllChannels() {
        $channels = $this->db->read('channels.json', ['channels' => []]);
        return $channels['channels'];
    }
    
    /**
     * الحصول على قناة محددة
     */
    public function getChannel($channel_id) {
        $channels = $this->getAllChannels();
        
        foreach ($channels as $channel) {
            if ($channel['channel_id'] == $channel_id) {
                return $channel;
            }
        }
        
        return null;
    }
    
    /**
     * فحص عضوية مستخدم في قناة
     */
    public function isMember($user_id, $channel_id) {
        $channel = $this->getChannel($channel_id);
        if (!$channel) return false;
        
        $result = $this->bot->getChatMember($channel_id, $user_id);
        
        if ($result && $result->ok) {
            $status = $result->result->status;
            return in_array($status, ['member', 'administrator', 'creator']);
        }
        
        return false;
    }
    
    /**
     * تحديث مشتركي القناة
     */
    public function updateChannelSubscribers($channel_id, $user_id) {
        $channels = $this->db->read('channels.json', ['channels' => []]);
        
        foreach ($channels['channels'] as &$channel) {
            if ($channel['channel_id'] == $channel_id) {
                if (!in_array($user_id, $channel['subscribers'])) {
                    $channel['subscribers'][] = $user_id;
                    $channel['current_count'] = count($channel['subscribers']);
                    
                    // فحص إذا تم الوصول للعدد المطلوب
                    if ($channel['current_count'] >= $channel['required_count']) {
                        $channel['completed'] = true;
                    }
                    
                    $this->db->write('channels.json', $channels);
                    return true;
                }
                return false; // المستخدم مشترك مسبقاً
            }
        }
        
        return false; // القناة غير موجودة
    }
    
    /**
     * فحص اكتمال جميع القنوات المطلوبة
     */
    public function checkCompletedChannels($user_id) {
        $channels = $this->getAllChannels();
        $completed_channels = 0;
        $total_required = 0;
        
        foreach ($channels as $channel) {
            if ($channel['is_active']) {
                $total_required++;
                if ($this->isMember($user_id, $channel['channel_id'])) {
                    $completed_channels++;
                }
            }
        }
        
        return [
            'completed' => $completed_channels,
            'total' => $total_required,
            'is_completed' => $completed_channels >= $total_required
        ];
    }
    
    /**
     * إعطاء مكافأة للمستخدم عند الاشتراك
     */
    public function giveSubscriptionReward($user_id, $channel_id, $user_manager) {
        $channel = $this->getChannel($channel_id);
        if (!$channel) return false;
        
        $rewards_given = false;
        
        // مكافأة النقاط
        if ($channel['reward_coins'] > 0) {
            $user_manager->addCoins($user_id, $channel['reward_coins'], "مكافأة اشتراك في قناة: " . $channel['title']);
            $rewards_given = true;
        }
        
        // مكافأة النجوم
        if ($channel['reward_stars'] > 0) {
            $user_manager->addStars($user_id, $channel['reward_stars'], "مكافأة اشتراك في قناة: " . $channel['title']);
            $rewards_given = true;
        }
        
        return $rewards_given;
    }
    
    /**
     * إنشاء رسالة الاشتراك الإجباري
     */
    public function createSubscriptionMessage($user_id, $user_manager) {
        $channels = $this->getAllChannels();
        $active_channels = array_filter($channels, function($channel) {
            return $channel['is_active'];
        });
        
        if (empty($active_channels)) {
            return null; // لا توجد قنوات مطلوبة
        }
        
        $message = "🔔 <b>الاشتراك الإجباري</b>\n\n";
        $message .= "يجب الاشتراك في القنوات التالية لاستخدام البوت:\n\n";
        
        $buttons = [];
        
        foreach ($active_channels as $channel) {
            $is_member = $this->isMember($user_id, $channel['channel_id']);
            $status_icon = $is_member ? "✅" : "❌";
            
            $message .= "$status_icon " . $channel['title'] . "\n";
            
            if (!$is_member) {
                $invite_link = $channel['invite_link'] ?: "https://t.me/" . $channel['username'];
                $buttons[] = [
                    ['text' => "اشتراك في " . $channel['title'], 'url' => $invite_link]
                ];
            }
        }
        
        $message .= "\nبعد الاشتراك اضغط على زر التحقق";
        
        // زر التحقق
        $buttons[] = [
            ['text' => "✅ تحقق من الاشتراك", 'callback_data' => "check_subscription"]
        ];
        
        return [
            'text' => $message,
            'keyboard' => $buttons
        ];
    }
    
    /**
     * إضافة مجموعة جديدة
     */
    public function addGroup($group_id, $group_data = []) {
        $groups = $this->db->read('groups.json', []);
        
        $group_info = array_merge([
            'group_id' => $group_id,
            'title' => $group_data['title'] ?? '',
            'username' => $group_data['username'] ?? '',
            'type' => $group_data['type'] ?? 'group',
            'member_count' => $group_data['member_count'] ?? 0,
            'is_active' => true,
            'added_date' => time(),
            'settings' => [
                'welcome_message' => true,
                'anti_spam' => true,
                'auto_delete_commands' => true
            ]
        ], $group_data);
        
        $groups[$group_id] = $group_info;
        $this->db->write('groups.json', $groups);
        
        return true;
    }
    
    /**
     * الحصول على جميع المجموعات
     */
    public function getAllGroups() {
        return $this->db->read('groups.json', []);
    }
    
    /**
     * الحصول على مجموعة محددة
     */
    public function getGroup($group_id) {
        $groups = $this->getAllGroups();
        return $groups[$group_id] ?? null;
    }
    
    /**
     * تحديث إعدادات مجموعة
     */
    public function updateGroupSettings($group_id, $settings) {
        $groups = $this->getAllGroups();
        
        if (isset($groups[$group_id])) {
            $groups[$group_id]['settings'] = array_merge($groups[$group_id]['settings'], $settings);
            $this->db->write('groups.json', $groups);
            return true;
        }
        
        return false;
    }
    
    /**
     * حذف مجموعة
     */
    public function removeGroup($group_id) {
        $groups = $this->getAllGroups();
        
        if (isset($groups[$group_id])) {
            unset($groups[$group_id]);
            $this->db->write('groups.json', $groups);
            return true;
        }
        
        return false;
    }
    
    /**
     * إحصائيات القنوات والمجموعات
     */
    public function getStats() {
        $channels = $this->getAllChannels();
        $groups = $this->getAllGroups();
        
        $total_subscribers = 0;
        $completed_channels = 0;
        
        foreach ($channels as $channel) {
            $total_subscribers += $channel['current_count'];
            if ($channel['completed']) {
                $completed_channels++;
            }
        }
        
        return [
            'channels' => [
                'total' => count($channels),
                'active' => count(array_filter($channels, function($c) { return $c['is_active']; })),
                'completed' => $completed_channels,
                'total_subscribers' => $total_subscribers
            ],
            'groups' => [
                'total' => count($groups),
                'active' => count(array_filter($groups, function($g) { return $g['is_active']; }))
            ]
        ];
    }
    
    /**
     * تنظيف القنوات غير النشطة
     */
    public function cleanupInactiveChannels($days = 30) {
        $channels = $this->db->read('channels.json', ['channels' => []]);
        $cutoff_time = time() - ($days * 24 * 60 * 60);
        $cleaned = 0;
        
        foreach ($channels['channels'] as $index => $channel) {
            if ($channel['added_date'] < $cutoff_time && !$channel['is_active']) {
                unset($channels['channels'][$index]);
                $cleaned++;
            }
        }
        
        if ($cleaned > 0) {
            $channels['channels'] = array_values($channels['channels']);
            $this->db->write('channels.json', $channels);
        }
        
        return $cleaned;
    }
    
    /**
     * تصدير بيانات القنوات
     */
    public function exportChannelsData() {
        $channels = $this->getAllChannels();
        $groups = $this->getAllGroups();
        
        return [
            'channels' => $channels,
            'groups' => $groups,
            'export_date' => date('Y-m-d H:i:s'),
            'total_channels' => count($channels),
            'total_groups' => count($groups)
        ];
    }
}
?>
