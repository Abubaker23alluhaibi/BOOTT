<?php
/**
 * كلاس إدارة المستخدمين
 * يتعامل مع جميع عمليات المستخدمين والنقاط والصلاحيات
 */

class UserManager {
    private $db;
    private $bot;
    
    public function __construct($database_manager, $telegram_bot) {
        $this->db = $database_manager;
        $this->bot = $telegram_bot;
    }
    
    /**
     * إضافة مستخدم جديد
     */
    public function addUser($user_id, $user_data = []) {
        $users = $this->db->read('users.json', []);
        
        if (!isset($users[$user_id])) {
            $users[$user_id] = array_merge([
                'id' => $user_id,
                'username' => $user_data['username'] ?? '',
                'first_name' => $user_data['first_name'] ?? '',
                'last_name' => $user_data['last_name'] ?? '',
                'coins' => 0,
                'points' => 0,
                'stars' => 0,
                'is_admin' => false,
                'is_blocked' => false,
                'join_date' => time(),
                'last_activity' => time(),
                'referral_code' => $this->generateReferralCode(),
                'referrals' => [],
                'total_spent' => 0,
                'total_earned' => 0,
                'packages' => [],
                'settings' => [
                    'notifications' => true,
                    'language' => 'ar'
                ]
            ], $user_data);
            
            $this->db->write('users.json', $users);
            return true;
        }
        
        return false;
    }
    
    /**
     * الحصول على معلومات مستخدم
     */
    public function getUser($user_id) {
        $users = $this->db->read('users.json', []);
        return $users[$user_id] ?? null;
    }
    
    /**
     * تحديث معلومات مستخدم
     */
    public function updateUser($user_id, $data) {
        $users = $this->db->read('users.json', []);
        
        if (isset($users[$user_id])) {
            $users[$user_id] = array_merge($users[$user_id], $data);
            $users[$user_id]['last_activity'] = time();
            $this->db->write('users.json', $users);
            return true;
        }
        
        return false;
    }
    
    /**
     * إضافة نقاط لمستخدم
     */
    public function addCoins($user_id, $amount, $reason = '') {
        $user = $this->getUser($user_id);
        if (!$user) return false;
        
        $new_balance = $user['coins'] + $amount;
        $this->updateUser($user_id, [
            'coins' => $new_balance,
            'total_earned' => $user['total_earned'] + $amount
        ]);
        
        // تسجيل المعاملة
        $this->logTransaction($user_id, 'add_coins', $amount, $reason);
        
        return $new_balance;
    }
    
    /**
     * خصم نقاط من مستخدم
     */
    public function deductCoins($user_id, $amount, $reason = '') {
        $user = $this->getUser($user_id);
        if (!$user || $user['coins'] < $amount) return false;
        
        $new_balance = $user['coins'] - $amount;
        $this->updateUser($user_id, [
            'coins' => $new_balance,
            'total_spent' => $user['total_spent'] + $amount
        ]);
        
        // تسجيل المعاملة
        $this->logTransaction($user_id, 'deduct_coins', $amount, $reason);
        
        return $new_balance;
    }
    
    /**
     * فحص رصيد المستخدم
     */
    public function checkBalance($user_id, $amount) {
        $user = $this->getUser($user_id);
        return $user ? $user['coins'] >= $amount : false;
    }
    
    /**
     * إضافة نجوم لمستخدم
     */
    public function addStars($user_id, $amount, $reason = '') {
        $user = $this->getUser($user_id);
        if (!$user) return false;
        
        $new_stars = $user['stars'] + $amount;
        $this->updateUser($user_id, ['stars' => $new_stars]);
        
        $this->logTransaction($user_id, 'add_stars', $amount, $reason);
        
        return $new_stars;
    }
    
    /**
     * حظر مستخدم
     */
    public function blockUser($user_id, $reason = '') {
        $this->updateUser($user_id, [
            'is_blocked' => true,
            'block_reason' => $reason,
            'block_date' => time()
        ]);
        
        $this->logTransaction($user_id, 'block_user', 0, $reason);
        return true;
    }
    
    /**
     * إلغاء حظر مستخدم
     */
    public function unblockUser($user_id) {
        $this->updateUser($user_id, [
            'is_blocked' => false,
            'block_reason' => '',
            'block_date' => null
        ]);
        
        $this->logTransaction($user_id, 'unblock_user', 0, '');
        return true;
    }
    
    /**
     * فحص إذا كان المستخدم محظور
     */
    public function isBlocked($user_id) {
        $user = $this->getUser($user_id);
        return $user ? $user['is_blocked'] : false;
    }
    
    /**
     * تعيين مستخدم كأدمن
     */
    public function setAdmin($user_id, $level = 1) {
        $this->updateUser($user_id, [
            'is_admin' => true,
            'admin_level' => $level,
            'admin_date' => time()
        ]);
        
        $this->logTransaction($user_id, 'set_admin', 0, "Level: $level");
        return true;
    }
    
    /**
     * إلغاء صلاحيات الأدمن
     */
    public function removeAdmin($user_id) {
        $this->updateUser($user_id, [
            'is_admin' => false,
            'admin_level' => 0,
            'admin_date' => null
        ]);
        
        $this->logTransaction($user_id, 'remove_admin', 0, '');
        return true;
    }
    
    /**
     * فحص إذا كان المستخدم أدمن
     */
    public function isAdmin($user_id) {
        $user = $this->getUser($user_id);
        return $user ? $user['is_admin'] : false;
    }
    
    /**
     * إضافة إحالة
     */
    public function addReferral($referrer_id, $referred_id) {
        $referrer = $this->getUser($referrer_id);
        if (!$referrer) return false;
        
        // إضافة المستخدم الجديد لقائمة الإحالات
        $referrals = $referrer['referrals'] ?? [];
        if (!in_array($referred_id, $referrals)) {
            $referrals[] = $referred_id;
            $this->updateUser($referrer_id, ['referrals' => $referrals]);
            
            // مكافأة الإحالة
            $this->addCoins($referrer_id, 10, 'مكافأة إحالة');
            
            $this->logTransaction($referrer_id, 'referral', 10, "Referred: $referred_id");
            return true;
        }
        
        return false;
    }
    
    /**
     * الحصول على إحصائيات المستخدم
     */
    public function getUserStats($user_id) {
        $user = $this->getUser($user_id);
        if (!$user) return null;
        
        return [
            'user_id' => $user_id,
            'username' => $user['username'],
            'first_name' => $user['first_name'],
            'coins' => $user['coins'],
            'stars' => $user['stars'],
            'referrals_count' => count($user['referrals'] ?? []),
            'total_spent' => $user['total_spent'],
            'total_earned' => $user['total_earned'],
            'join_date' => $user['join_date'],
            'last_activity' => $user['last_activity'],
            'is_admin' => $user['is_admin'],
            'is_blocked' => $user['is_blocked']
        ];
    }
    
    /**
     * الحصول على جميع المستخدمين
     */
    public function getAllUsers($limit = null, $offset = 0) {
        $users = $this->db->read('users.json', []);
        
        if ($limit) {
            $users = array_slice($users, $offset, $limit, true);
        }
        
        return $users;
    }
    
    /**
     * البحث عن مستخدمين
     */
    public function searchUsers($query) {
        $users = $this->getAllUsers();
        $results = [];
        
        foreach ($users as $user_id => $user) {
            if (stripos($user['username'], $query) !== false ||
                stripos($user['first_name'], $query) !== false ||
                stripos($user['last_name'], $query) !== false) {
                $results[$user_id] = $user;
            }
        }
        
        return $results;
    }
    
    /**
     * تسجيل معاملة
     */
    private function logTransaction($user_id, $type, $amount, $reason) {
        $transactions = $this->db->read('transactions.json', []);
        
        $transaction = [
            'user_id' => $user_id,
            'type' => $type,
            'amount' => $amount,
            'reason' => $reason,
            'timestamp' => time(),
            'date' => date('Y-m-d H:i:s')
        ];
        
        $transactions[] = $transaction;
        
        // الاحتفاظ بآخر 1000 معاملة فقط
        if (count($transactions) > 1000) {
            $transactions = array_slice($transactions, -1000);
        }
        
        $this->db->write('transactions.json', $transactions);
    }
    
    /**
     * الحصول على سجل المعاملات
     */
    public function getTransactions($user_id = null, $limit = 50) {
        $transactions = $this->db->read('transactions.json', []);
        
        if ($user_id) {
            $transactions = array_filter($transactions, function($t) use ($user_id) {
                return $t['user_id'] == $user_id;
            });
        }
        
        return array_slice(array_reverse($transactions), 0, $limit);
    }
    
    /**
     * توليد كود إحالة فريد
     */
    private function generateReferralCode() {
        do {
            $code = strtoupper(substr(md5(uniqid()), 0, 8));
            $users = $this->getAllUsers();
            $exists = false;
            
            foreach ($users as $user) {
                if (isset($user['referral_code']) && $user['referral_code'] === $code) {
                    $exists = true;
                    break;
                }
            }
        } while ($exists);
        
        return $code;
    }
    
    /**
     * تنسيق الأرقام
     */
    public function formatNumber($number) {
        $suffixes = ['', 'k', 'm', 'b', 't'];
        $suffix_index = 0;
        
        while ($number >= 1000 && $suffix_index < count($suffixes) - 1) {
            $number /= 1000;
            $suffix_index++;
        }
        
        return round($number, 1) . $suffixes[$suffix_index];
    }
    
    /**
     * تنظيف المستخدمين غير النشطين
     */
    public function cleanupInactiveUsers($days = 30) {
        $users = $this->getAllUsers();
        $cutoff_time = time() - ($days * 24 * 60 * 60);
        $cleaned = 0;
        
        foreach ($users as $user_id => $user) {
            if ($user['last_activity'] < $cutoff_time && !$user['is_admin']) {
                unset($users[$user_id]);
                $cleaned++;
            }
        }
        
        if ($cleaned > 0) {
            $this->db->write('users.json', $users);
        }
        
        return $cleaned;
    }
}
?>
