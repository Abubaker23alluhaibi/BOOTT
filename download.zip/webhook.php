<?php
/**
 * ملف Webhook للبوت المنظم
 * نقطة الدخول الرئيسية للتليجرام
 */

// تضمين الملف الرئيسي
require_once 'main.php';

// تشغيل البوت
try {
    $bot = new OrganizedBot();
} catch (Exception $e) {
    error_log("Bot Error: " . $e->getMessage());
    
    // إرسال رسالة خطأ للمطور
    if (defined('SUDO_ID') && SUDO_ID) {
        $error_message = "❌ خطأ في البوت:\n" . $e->getMessage();
        $bot_api = "https://api.telegram.org/bot" . API_KEY . "/sendMessage";
        $post_data = [
            'chat_id' => SUDO_ID,
            'text' => $error_message,
            'parse_mode' => 'HTML'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $bot_api);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_exec($ch);
        curl_close($ch);
    }
}
?>
